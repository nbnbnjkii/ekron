import { useCallback, useEffect, useRef, useState } from "react";
import { LobbyEngine } from "./game/engine";
import Splash from "./components/Splash";
import Hud from "./components/Hud";
import TouchControls from "./components/TouchControls";
import SessionOverlay from "./components/SessionOverlay";

type Stage = "splash" | "lobby" | "session";

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<LobbyEngine | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);

  const [engine, setEngine] = useState<LobbyEngine | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [stage, setStage] = useState<Stage>("splash");
  const [sessionKind, setSessionKind] = useState<"new" | "resume">("new");
  const [over, setOver] = useState(false);
  const [locked, setLocked] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;
    let cancelled = false;
    let created: LobbyEngine | null = null;

    const showToast = (text: string) => {
      setToast(text);
      window.clearTimeout(toastTimer.current);
      toastTimer.current = window.setTimeout(() => setToast(null), 3800);
    };
    const beginSession = (kind: "new" | "resume") => {
      const e = engineRef.current;
      if (!e) return;
      e.setPaused(true);
      e.sessionStarted();
      setSessionKind(kind);
      setStage("session");
      setOver(false);
      setLocked(false);
    };

    LobbyEngine.create(el, {
      onResume: () => beginSession("resume"),
      onNewGame: () => beginSession("new"),
      onHover: setOver,
      onLockChange: setLocked,
      onToast: showToast,
    })
      .then((e) => {
        if (cancelled) {
          e.dispose();
          return;
        }
        created = e;
        engineRef.current = e;
        setEngine(e);
      })
      .catch((err: unknown) => {
        if (!cancelled) setError(err instanceof Error ? err.message : String(err));
      });

    return () => {
      cancelled = true;
      window.clearTimeout(toastTimer.current);
      created?.dispose();
      engineRef.current = null;
      setEngine(null);
    };
  }, []);

  const enter = useCallback(() => {
    engineRef.current?.start();
    setStage("lobby");
  }, []);

  const leaveSession = useCallback(() => {
    const e = engineRef.current;
    e?.setPaused(false);
    e?.returnedToLobby();
    setStage("lobby");
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#050806]">
      <div ref={mountRef} className="absolute inset-0" />

      {engine && stage === "lobby" && <Hud engine={engine} over={over} locked={locked} toast={toast} />}
      {engine && stage === "lobby" && engine.isTouch && <TouchControls engine={engine} />}

      {stage === "splash" && <Splash ready={!!engine} error={error} onEnter={enter} />}
      {stage === "session" && <SessionOverlay kind={sessionKind} onExit={leaveSession} />}
    </div>
  );
}
