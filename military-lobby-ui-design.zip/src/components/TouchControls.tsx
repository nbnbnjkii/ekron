import { useRef, useState } from "react";
import type { LobbyEngine } from "../game/engine";

const R = 52; // max stick travel in px

export default function TouchControls({ engine }: { engine: LobbyEngine }) {
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const [crouch, setCrouch] = useState(false);
  const [jumpDown, setJumpDown] = useState(false);
  const baseRef = useRef<HTMLDivElement>(null);
  const activeId = useRef<number | null>(null);

  const update = (e: React.PointerEvent) => {
    const r = baseRef.current!.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    const len = Math.hypot(dx, dy);
    if (len > R) {
      dx = (dx / len) * R;
      dy = (dy / len) * R;
    }
    setKnob({ x: dx, y: dy });
    const nx = dx / R;
    const ny = dy / R;
    const dead = 0.14;
    engine.setStick(Math.abs(nx) < dead ? 0 : nx, Math.abs(ny) < dead ? 0 : -ny);
  };

  const end = () => {
    activeId.current = null;
    setKnob({ x: 0, y: 0 });
    engine.setStick(0, 0);
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-20 select-none">
      {/* walk stick */}
      <div
        ref={baseRef}
        className="pointer-events-auto absolute bottom-6 left-5 h-36 w-36 touch-none rounded-full border border-emerald-300/35 bg-black/35 backdrop-blur-sm"
        style={{ bottom: "max(1.5rem, env(safe-area-inset-bottom))" }}
        onPointerDown={(e) => {
          if (activeId.current !== null) return;
          activeId.current = e.pointerId;
          e.currentTarget.setPointerCapture(e.pointerId);
          update(e);
        }}
        onPointerMove={(e) => {
          if (activeId.current === e.pointerId) update(e);
        }}
        onPointerUp={(e) => {
          if (activeId.current === e.pointerId) end();
        }}
        onPointerCancel={end}
      >
        <div className="absolute inset-3 rounded-full border border-dashed border-emerald-300/25" />
        <div
          className="absolute left-1/2 top-1/2 h-14 w-14 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-emerald-200/70 bg-emerald-400/25 shadow-[0_0_18px_rgba(93,255,154,0.4)]"
          style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
        />
        <span className="absolute left-1/2 top-1.5 -translate-x-1/2 text-[9px] font-bold tracking-widest text-emerald-200/60">
          ХОД
        </span>
      </div>

      {/* action buttons */}
      <div
        className="absolute right-4 flex flex-col gap-3"
        style={{ bottom: "max(1.5rem, env(safe-area-inset-bottom))" }}
      >
        <button
          onPointerDown={(e) => {
            e.preventDefault();
            setJumpDown(true);
            engine.touchJump();
          }}
          onPointerUp={() => setJumpDown(false)}
          onPointerCancel={() => setJumpDown(false)}
          className={`pointer-events-auto flex h-16 w-16 touch-none flex-col items-center justify-center rounded-full border-2 text-[9px] font-extrabold tracking-wider backdrop-blur-sm transition ${
            jumpDown
              ? "scale-95 border-emerald-100 bg-emerald-400/50 text-white"
              : "border-emerald-300/50 bg-black/40 text-emerald-100"
          }`}
        >
          <svg viewBox="0 0 24 24" className="mb-0.5 h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2.4">
            <path d="M12 19V5M5 12l7-7 7 7" />
          </svg>
          ПРЫЖОК
        </button>
        <button
          onPointerDown={(e) => {
            e.preventDefault();
            setCrouch(engine.toggleCrouch());
          }}
          className={`pointer-events-auto flex h-16 w-16 touch-none flex-col items-center justify-center rounded-full border-2 text-[9px] font-extrabold tracking-wider backdrop-blur-sm transition ${
            crouch
              ? "border-amber-300 bg-amber-400/30 text-amber-100"
              : "border-emerald-300/50 bg-black/40 text-emerald-100"
          }`}
        >
          <svg viewBox="0 0 24 24" className="mb-0.5 h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2.4">
            <path d="M12 5v14M5 12l7 7 7-7" />
          </svg>
          ПРИСЕСТЬ
        </button>
      </div>
    </div>
  );
}
