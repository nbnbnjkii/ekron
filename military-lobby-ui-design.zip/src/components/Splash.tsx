import { useEffect } from "react";

interface Props {
  ready: boolean;
  error: string | null;
  onEnter: () => void;
}

function Star({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" className={className} aria-hidden>
      <circle cx="50" cy="50" r="46" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="6 5" />
      <circle cx="50" cy="50" r="38" fill="none" stroke="currentColor" strokeWidth="1.2" opacity=".6" />
      <polygon
        points="50,14 59.4,38.6 85.7,39.7 65.1,56 72.1,81.3 50,66.9 27.9,81.3 34.9,56 14.3,39.7 40.6,38.6"
        fill="currentColor"
      />
    </svg>
  );
}

export default function Splash({ ready, error, onEnter }: Props) {
  useEffect(() => {
    if (!ready) return;
    const h = (e: KeyboardEvent) => {
      if (e.code === "Enter" || e.code === "Space") {
        e.preventDefault();
        onEnter();
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [ready, onEnter]);

  return (
    <div className="anim-fade-in fixed inset-0 z-30 flex items-center justify-center overflow-hidden bg-[radial-gradient(ellipse_at_center,rgba(3,9,6,0.5)_0%,rgba(2,5,3,0.9)_75%)] backdrop-blur-[3px]">
      <div className="grid-bg pointer-events-none absolute inset-0 opacity-60" />
      <div className="scanlines pointer-events-none absolute inset-0" />
      <div className="anim-scan pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-transparent via-emerald-300/10 to-transparent" />

      {/* corner brackets */}
      {[
        "left-4 top-4 border-l-2 border-t-2",
        "right-4 top-4 border-r-2 border-t-2",
        "bottom-4 left-4 border-b-2 border-l-2",
        "bottom-4 right-4 border-b-2 border-r-2",
      ].map((c) => (
        <div key={c} className={`pointer-events-none absolute h-8 w-8 border-emerald-300/60 sm:h-12 sm:w-12 ${c}`} />
      ))}

      <div className="relative z-10 mx-auto flex max-w-xl flex-col items-center px-6 text-center">
        <div className="anim-fade-up relative mb-5 text-emerald-300" style={{ animationDelay: "0.05s" }}>
          <span className="anim-ring absolute inset-0 rounded-full border border-emerald-300/50" />
          <Star className="h-20 w-20 drop-shadow-[0_0_14px_rgba(93,255,154,0.7)] sm:h-24 sm:w-24" />
        </div>

        <div
          className="anim-fade-up mb-3 flex items-center gap-3 text-[11px] font-bold tracking-[0.35em] text-amber-300 sm:text-xs"
          style={{ animationDelay: "0.15s" }}
        >
          <span className="h-px w-8 bg-amber-300/60" />
          СЕКРЕТНО · ДОПУСК 4
          <span className="h-px w-8 bg-amber-300/60" />
        </div>

        <h1
          className="anim-fade-up anim-glow font-display text-6xl tracking-[0.18em] text-emerald-100 sm:text-8xl"
          style={{ animationDelay: "0.25s" }}
        >
          ЭКРОН
        </h1>
        <p
          className="anim-fade-up mt-3 text-sm font-bold tracking-[0.4em] text-emerald-300/90 sm:text-base"
          style={{ animationDelay: "0.4s" }}
        >
          КОМАНДНЫЙ ПУНКТ · ЛОББИ
        </p>

        <div className="anim-fade-up mt-10 w-full max-w-sm" style={{ animationDelay: "0.55s" }}>
          {error ? (
            <div className="rounded-md border border-red-400/50 bg-red-950/60 p-4 text-left text-sm text-red-200">
              <div className="mb-1 font-bold tracking-widest text-red-300">ОШИБКА ИНИЦИАЛИЗАЦИИ</div>
              Не удалось запустить 3D-режим (нужен браузер с поддержкой WebGL2).
              <div className="mt-2 break-words text-xs text-red-300/70">{error}</div>
            </div>
          ) : ready ? (
            <button
              onClick={onEnter}
              className="military-btn group relative w-full cursor-pointer border-0 bg-gradient-to-r from-emerald-700 to-emerald-500 px-8 py-4 font-display text-xl tracking-[0.3em] text-emerald-50 shadow-[0_0_40px_rgba(52,211,153,0.35)] transition hover:from-emerald-600 hover:to-emerald-400 hover:shadow-[0_0_60px_rgba(52,211,153,0.6)] active:scale-[0.98]"
            >
              <span className="relative z-10">ВОЙТИ В ЛОББИ</span>
              <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
            </button>
          ) : (
            <div>
              <div className="mb-2 flex justify-between text-[11px] font-bold tracking-[0.25em] text-emerald-300/80">
                <span>ЗАГРУЗКА КОМНАТЫ</span>
                <span className="anim-blink">●●●</span>
              </div>
              <div className="h-2 overflow-hidden rounded-sm border border-emerald-300/30 bg-black/50">
                <div className="h-full w-1/3 animate-[pulse_1s_ease-in-out_infinite] bg-gradient-to-r from-emerald-600 to-emerald-300" />
              </div>
            </div>
          )}
        </div>

        <div
          className="anim-fade-up mt-8 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-[11px] tracking-widest text-emerald-200/60"
          style={{ animationDelay: "0.7s" }}
        >
          <span>◼ 4 МОНИТОРА</span>
          <span>◼ ОБЗОР 360°</span>
          <span>◼ WASD / СЕНСОР</span>
        </div>
      </div>
    </div>
  );
}
