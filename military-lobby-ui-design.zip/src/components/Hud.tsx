import { useEffect, useState } from "react";
import type { LobbyEngine } from "../game/engine";

interface Props {
  engine: LobbyEngine;
  over: boolean;
  locked: boolean;
  toast: string | null;
}

const NAV = [
  { n: 1, name: "Командный пункт" },
  { n: 2, name: "Настройки" },
  { n: 3, name: "Интро" },
  { n: 4, name: "Руководство" },
];

function Kbd({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="rounded border border-emerald-300/40 bg-emerald-950/70 px-1.5 py-0.5 text-[10px] font-bold text-emerald-200 shadow-[0_2px_0_rgba(0,0,0,0.5)]">
      {children}
    </kbd>
  );
}

export default function Hud({ engine, over, locked, toast }: Props) {
  const [full, setFull] = useState(false);
  const [faded, setFaded] = useState(false);
  const touch = engine.isTouch;

  // the key hints dim after a while so they do not cover the room
  useEffect(() => {
    const id = window.setTimeout(() => setFaded(true), 10000);
    return () => window.clearTimeout(id);
  }, []);

  useEffect(() => {
    const h = () => setFull(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", h);
    return () => document.removeEventListener("fullscreenchange", h);
  }, []);

  const toggleFull = () => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.documentElement.requestFullscreen?.().catch(() => undefined);
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-20 select-none">
      {/* brand */}
      <div className="anim-fade-in absolute left-3 top-3 flex items-center gap-3 rounded-lg border border-emerald-300/20 bg-black/40 px-3 py-2 backdrop-blur-md sm:left-5 sm:top-5">
        <svg viewBox="0 0 100 100" className="h-8 w-8 text-emerald-300" aria-hidden>
          <circle cx="50" cy="50" r="44" fill="none" stroke="currentColor" strokeWidth="4" />
          <polygon
            points="50,16 59.4,40 85,41 65,57 72,82 50,68 28,82 35,57 15,41 40.6,40"
            fill="currentColor"
          />
        </svg>
        <div className="leading-tight">
          <div className="font-display text-base tracking-[0.2em] text-emerald-100">ЭКРОН</div>
          <div className="text-[10px] font-bold tracking-[0.25em] text-emerald-300/70">ЛОББИ · УЗЕЛ 01</div>
        </div>
      </div>

      {/* monitor navigation */}
      <div className="pointer-events-auto absolute right-3 top-3 flex items-stretch gap-1.5 sm:right-5 sm:top-5">
        {NAV.map((m) => (
          <button
            key={m.n}
            onClick={(e) => {
              engine.focusScreen(m.n - 1);
              e.currentTarget.blur();
            }}
            title={`К экрану ${m.n}: ${m.name}`}
            className="group flex cursor-pointer items-center gap-2 rounded-lg border border-emerald-300/25 bg-black/45 px-2.5 py-2 text-emerald-100 backdrop-blur-md transition hover:border-emerald-300/70 hover:bg-emerald-900/50 active:scale-95"
          >
            <span className="flex h-6 w-6 items-center justify-center rounded border border-emerald-300/50 bg-emerald-400/10 text-xs font-extrabold text-emerald-200 group-hover:bg-emerald-300 group-hover:text-emerald-950">
              {m.n}
            </span>
            <span className="hidden text-[11px] font-bold uppercase tracking-wider lg:inline">{m.name}</span>
          </button>
        ))}
        <button
          onClick={(e) => {
            toggleFull();
            e.currentTarget.blur();
          }}
          title="Полный экран"
          className="flex cursor-pointer items-center rounded-lg border border-emerald-300/25 bg-black/45 px-2.5 text-emerald-100 backdrop-blur-md transition hover:border-emerald-300/70 hover:bg-emerald-900/50 active:scale-95"
        >
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.2">
            {full ? (
              <path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5" />
            ) : (
              <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />
            )}
          </svg>
        </button>
      </div>

      {/* crosshair (pointer-lock mode) */}
      {locked && (
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div
            className={`relative h-7 w-7 rounded-full border-2 transition-all duration-150 ${
              over ? "scale-125 border-amber-300 shadow-[0_0_14px_rgba(255,194,71,0.8)]" : "border-emerald-200/70"
            }`}
          >
            <span
              className={`absolute left-1/2 top-1/2 h-1 w-1 -translate-x-1/2 -translate-y-1/2 rounded-full ${
                over ? "bg-amber-300" : "bg-emerald-200"
              }`}
            />
          </div>
        </div>
      )}

      {/* toast */}
      {toast && (
        <div className="anim-fade-up absolute left-1/2 top-20 -translate-x-1/2 rounded-md border border-amber-300/50 bg-black/70 px-4 py-2 text-xs font-bold tracking-wide text-amber-200 backdrop-blur-md">
          {toast}
        </div>
      )}

      {/* hints */}
      {!touch && (
        <div
          className={`absolute inset-x-0 bottom-3 flex justify-center px-3 transition-opacity duration-700 sm:bottom-5 ${
            faded && !locked ? "opacity-35" : "opacity-100"
          }`}
        >
          <div className="flex max-w-4xl flex-wrap items-center justify-center gap-x-4 gap-y-1.5 rounded-xl border border-emerald-300/20 bg-black/45 px-4 py-2 text-[11px] text-emerald-100/85 backdrop-blur-md">
            {locked ? (
              <>
                <span className="flex items-center gap-1.5"><Kbd>WASD</Kbd> ходьба</span>
                <span className="flex items-center gap-1.5"><Kbd>ЛКМ</Kbd>/<Kbd>E</Kbd> нажать</span>
                <span className="flex items-center gap-1.5"><Kbd>Пробел</Kbd> прыжок</span>
                <span className="flex items-center gap-1.5"><Kbd>C</Kbd> присесть</span>
                <span className="flex items-center gap-1.5"><Kbd>Esc</Kbd> отпустить мышь</span>
              </>
            ) : (
              <>
                <span className="flex items-center gap-1.5"><Kbd>WASD</Kbd> ходьба</span>
                <span className="flex items-center gap-1.5"><Kbd>Тяните мышью</Kbd> обзор</span>
                <span className="flex items-center gap-1.5"><Kbd>Клик</Kbd> по кнопке на экране</span>
                <span className="flex items-center gap-1.5"><Kbd>Пробел</Kbd> прыжок</span>
                <span className="flex items-center gap-1.5"><Kbd>C</Kbd> присесть</span>
                <span className="flex items-center gap-1.5"><Kbd>1–4</Kbd> к экрану</span>
                <span className="flex items-center gap-1.5"><Kbd>L</Kbd> захват мыши</span>
                <span className="flex items-center gap-1.5"><Kbd>M</Kbd> звук</span>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
