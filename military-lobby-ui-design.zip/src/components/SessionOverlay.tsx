import { useEffect, useState } from "react";

interface Props {
  kind: "new" | "resume";
  onExit: () => void;
}

const LOG_NEW = [
  "Подключение к игровому серверу…",
  "Загрузка карты «Творческий»…",
  "Синхронизация инвентаря…",
  "Развёртывание игрока…",
  "Готово. Удачной операции!",
];
const LOG_RESUME = [
  "Поиск сохранённой сессии…",
  "Восстановление позиции игрока…",
  "Синхронизация мира…",
  "Готово. С возвращением, командир!",
];

const pad = (n: number) => String(n).padStart(2, "0");

export default function SessionOverlay({ kind, onExit }: Props) {
  const log = kind === "new" ? LOG_NEW : LOG_RESUME;
  const duration = kind === "new" ? 3000 : 2000;
  const [progress, setProgress] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const active = progress >= 1;

  useEffect(() => {
    const t0 = performance.now();
    const id = setInterval(() => {
      const p = Math.min(1, (performance.now() - t0) / duration);
      setProgress(p);
      if (p >= 1) clearInterval(id);
    }, 40);
    return () => clearInterval(id);
  }, [duration]);

  useEffect(() => {
    if (!active) return;
    const t0 = performance.now();
    const id = setInterval(() => setElapsed(Math.floor((performance.now() - t0) / 1000)), 250);
    const key = (e: KeyboardEvent) => {
      if (e.code === "Escape") onExit();
    };
    window.addEventListener("keydown", key);
    return () => {
      clearInterval(id);
      window.removeEventListener("keydown", key);
    };
  }, [active, onExit]);

  const shown = Math.min(log.length, Math.floor(progress * log.length) + 1);

  return (
    <div className="anim-fade-in fixed inset-0 z-40 flex items-center justify-center overflow-hidden bg-[#040a07]">
      <div className="grid-bg absolute inset-0" />
      <div className="scanlines pointer-events-none absolute inset-0" />
      <div className="anim-scan pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-transparent via-emerald-300/10 to-transparent" />

      <div className="relative z-10 flex w-full max-w-3xl flex-col items-center gap-8 px-6 md:flex-row md:items-center">
        {/* radar */}
        <div className="relative h-52 w-52 shrink-0 sm:h-64 sm:w-64">
          <div className="absolute inset-0 rounded-full border-2 border-emerald-300/60 shadow-[0_0_40px_rgba(52,211,153,0.3)]" />
          {[0.75, 0.5, 0.25].map((s) => (
            <div
              key={s}
              className="absolute left-1/2 top-1/2 rounded-full border border-emerald-300/30"
              style={{ width: `${s * 100}%`, height: `${s * 100}%`, transform: "translate(-50%,-50%)" }}
            />
          ))}
          <div className="absolute left-0 top-1/2 h-px w-full bg-emerald-300/25" />
          <div className="absolute left-1/2 top-0 h-full w-px bg-emerald-300/25" />
          <div
            className={`absolute inset-0 rounded-full ${active ? "" : "anim-sweep"}`}
            style={{
              background: "conic-gradient(from 0deg, rgba(93,255,154,0) 0deg, rgba(93,255,154,0) 270deg, rgba(93,255,154,0.55) 360deg)",
            }}
          />
          {[
            [30, 30],
            [66, 40],
            [55, 70],
            [28, 62],
          ].map(([x, y], i) => (
            <span
              key={i}
              className="anim-blink absolute h-2 w-2 rounded-full bg-amber-300 shadow-[0_0_8px_rgba(255,194,71,0.9)]"
              style={{ left: `${x}%`, top: `${y}%`, animationDelay: `${i * 0.3}s` }}
            />
          ))}
          <div className="absolute left-1/2 top-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-emerald-200" />
        </div>

        {/* status */}
        <div className="w-full flex-1">
          <div className="mb-1 text-[11px] font-bold tracking-[0.35em] text-amber-300">
            {kind === "new" ? "НОВАЯ ИГРА · ТВОРЧЕСКИЙ РЕЖИМ" : "ПРОДОЛЖЕНИЕ СЕССИИ"}
          </div>
          <h2 className="font-display text-3xl tracking-[0.12em] text-emerald-100 sm:text-4xl">
            {active ? "СЕССИЯ АКТИВНА" : "РАЗВЁРТЫВАНИЕ"}
          </h2>

          <div className="mt-5 min-h-[7.5rem] space-y-1.5 text-sm">
            {log.slice(0, shown).map((l, i) => (
              <div
                key={l}
                className={`anim-fade-in flex items-center gap-2 ${
                  i === shown - 1 && !active ? "text-emerald-100" : "text-emerald-300/70"
                }`}
              >
                <span className={i < shown - 1 || active ? "text-emerald-400" : "anim-blink text-amber-300"}>
                  {i < shown - 1 || active ? "✔" : "▶"}
                </span>
                {l}
              </div>
            ))}
          </div>

          {!active ? (
            <div className="mt-4">
              <div className="mb-1.5 flex justify-between text-[11px] font-bold tracking-widest text-emerald-300/80">
                <span>ЗАГРУЗКА</span>
                <span>{Math.round(progress * 100)}%</span>
              </div>
              <div className="h-3 overflow-hidden rounded-sm border border-emerald-300/40 bg-black/60 p-0.5">
                <div
                  className="h-full bg-gradient-to-r from-emerald-600 to-emerald-300 shadow-[0_0_12px_rgba(93,255,154,0.7)]"
                  style={{ width: `${progress * 100}%` }}
                />
              </div>
            </div>
          ) : (
            <div className="anim-fade-up mt-4">
              <div className="mb-4 grid grid-cols-3 gap-2 text-center">
                {[
                  ["ВРЕМЯ", `${pad(Math.floor(elapsed / 60))}:${pad(elapsed % 60)}`],
                  ["РЕЖИМ", "ТВОРЧЕСКИЙ"],
                  ["СТАТУС", "В СЕТИ"],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-md border border-emerald-300/25 bg-emerald-950/50 px-2 py-2">
                    <div className="text-[9px] font-bold tracking-[0.25em] text-emerald-300/60">{k}</div>
                    <div className="text-sm font-extrabold text-emerald-100">{v}</div>
                  </div>
                ))}
              </div>
              <p className="mb-4 text-xs leading-relaxed text-emerald-200/60">
                Лобби — это только меню: здесь запускается игровая сессия. Нажмите «Продолжить игру» или «Сохранить игру»
                на главном мониторе, когда вернётесь.
              </p>
              <button
                onClick={onExit}
                className="military-btn w-full cursor-pointer bg-gradient-to-r from-emerald-700 to-emerald-500 px-6 py-3.5 font-display text-base tracking-[0.25em] text-emerald-50 shadow-[0_0_30px_rgba(52,211,153,0.3)] transition hover:from-emerald-600 hover:to-emerald-400 active:scale-[0.98]"
              >
                ВЕРНУТЬСЯ В ЛОББИ <span className="ml-2 text-xs opacity-70">ESC</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
