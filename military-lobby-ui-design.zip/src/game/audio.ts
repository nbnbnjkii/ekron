/** Tiny procedural sound engine: ambient bunker hum, UI blips, footsteps, radar ping. */
export class LobbyAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private ambient: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  muted = false;

  init() {
    if (this.ctx) {
      void this.ctx.resume();
      return;
    }
    const Ctor: typeof AudioContext | undefined =
      window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return;
    this.ctx = new Ctor();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.9;
    this.master.connect(this.ctx.destination);

    // noise buffer
    const len = this.ctx.sampleRate * 2;
    this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;

    this.startAmbient();
  }

  private startAmbient() {
    const ctx = this.ctx;
    if (!ctx || !this.master || !this.noiseBuf) return;
    const amb = ctx.createGain();
    amb.gain.value = 0.55;
    amb.connect(this.master);
    this.ambient = amb;

    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 180;
    lp.connect(amb);
    for (const [f, g, type] of [
      [50, 0.09, "sine"],
      [100.4, 0.05, "sawtooth"],
      [151, 0.02, "sine"],
    ] as const) {
      const o = ctx.createOscillator();
      o.type = type;
      o.frequency.value = f;
      const og = ctx.createGain();
      og.gain.value = g;
      o.connect(og).connect(lp);
      o.start();
    }

    const n = ctx.createBufferSource();
    n.buffer = this.noiseBuf;
    n.loop = true;
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 520;
    bp.Q.value = 0.7;
    const ng = ctx.createGain();
    ng.gain.value = 0.035;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.07;
    const lfoG = ctx.createGain();
    lfoG.gain.value = 180;
    lfo.connect(lfoG).connect(bp.frequency);
    lfo.start();
    n.connect(bp).connect(ng).connect(amb);
    n.start();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.ctx && this.master) this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.05);
  }

  /** duck the ambience when a game session overlay is shown */
  setAmbientLevel(v: number) {
    if (this.ctx && this.ambient) this.ambient.gain.setTargetAtTime(v, this.ctx.currentTime, 0.2);
  }

  private tone(freq: number, dur: number, type: OscillatorType, gain: number, slideTo?: number, when = 0) {
    const ctx = this.ctx;
    if (!ctx || !this.master) return;
    const t = ctx.currentTime + when;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private burst(dur: number, freq: number, gain: number) {
    const ctx = this.ctx;
    if (!ctx || !this.master || !this.noiseBuf) return;
    const t = ctx.currentTime;
    const s = ctx.createBufferSource();
    s.buffer = this.noiseBuf;
    const f = ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(this.master);
    s.start(t, Math.random());
    s.stop(t + dur + 0.02);
  }

  click() {
    this.tone(880, 0.07, "square", 0.07, 1320);
    this.tone(440, 0.09, "triangle", 0.05, 330, 0.02);
  }
  ok() {
    this.tone(660, 0.09, "square", 0.06);
    this.tone(990, 0.14, "square", 0.06, undefined, 0.09);
  }
  deny() {
    this.tone(180, 0.18, "sawtooth", 0.07, 120);
  }
  step() {
    this.burst(0.09, 380 + Math.random() * 120, 0.16);
  }
  jump() {
    this.burst(0.08, 600, 0.1);
  }
  land() {
    this.burst(0.18, 260, 0.3);
    this.tone(70, 0.16, "sine", 0.18, 40);
  }
  ping(volume: number) {
    if (volume <= 0.02) return;
    this.tone(1560, 0.9, "sine", 0.05 * volume, 1500);
  }
  deploy() {
    this.tone(220, 0.5, "sawtooth", 0.05, 880);
    this.tone(880, 0.3, "square", 0.04, undefined, 0.5);
  }
}
