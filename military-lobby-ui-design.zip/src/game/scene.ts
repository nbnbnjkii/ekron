import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { RectAreaLightUniformsLib } from "three/examples/jsm/lights/RectAreaLightUniformsLib.js";
import * as TX from "./textures";
import { type Box, boxFromCenter } from "./player";

export const SCREEN_W = 6.4;
export const SCREEN_H = 3.6;
export const SCREEN_CY = 2.1;

/** Wall i: position of the wall plane and rotation so local +z points into the room. */
export const WALLS = [
  { x: 0, z: -8, rotY: 0 },
  { x: 8, z: 0, rotY: -Math.PI / 2 },
  { x: 0, z: 8, rotY: Math.PI },
  { x: -8, z: 0, rotY: Math.PI / 2 },
];

export function wallNormal(i: number) {
  const r = WALLS[i].rotY;
  return new THREE.Vector3(Math.sin(r), 0, Math.cos(r));
}

/** Nice standing spot in front of monitor i and the yaw/pitch that centres it. */
export function viewSpot(i: number) {
  const w = WALLS[i];
  const n = wallNormal(i);
  const d = 4.4;
  return { x: w.x + n.x * d, z: w.z + n.z * d, yaw: w.rotY, pitch: Math.atan2(SCREEN_CY - 1.7, d) };
}

export interface World {
  scene: THREE.Scene;
  screens: THREE.Mesh[];
  colliders: Box[];
  update(t: number, dt: number): void;
  setShadows(level: 0 | 1 | 2): void;
  dispose(): void;
}

const CONE_VS = /* glsl */ `
varying vec3 vN; varying vec3 vV; varying vec2 vUv;
void main(){
  vUv = uv;
  vN = normalize(normalMatrix * normal);
  vec4 mv = modelViewMatrix * vec4(position,1.0);
  vV = normalize(-mv.xyz);
  gl_Position = projectionMatrix * mv;
}`;
const CONE_FS = /* glsl */ `
uniform vec3 uColor; uniform float uIntensity; uniform float uInvert;
varying vec3 vN; varying vec3 vV; varying vec2 vUv;
void main(){
  float f = pow(abs(dot(normalize(vN), normalize(vV))), 1.6);
  float h = mix(vUv.y, 1.0 - vUv.y, uInvert);
  float a = pow(h, 1.5) * f * uIntensity;
  gl_FragColor = vec4(uColor, a);
}`;

export function buildWorld(screenTex: THREE.Texture[]): World {
  RectAreaLightUniformsLib.init();

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x050806);
  scene.fog = new THREE.FogExp2(0x070b08, 0.014);

  const disposables: { dispose(): void }[] = [];
  const track = <T extends { dispose(): void }>(o: T): T => {
    disposables.push(o);
    return o;
  };
  const colliders: Box[] = [];

  const mat = (color: number | string, rough = 0.8, metal = 0, extra: THREE.MeshStandardMaterialParameters = {}) =>
    track(new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal, ...extra }));
  const emis = (color: number, mult = 1) => {
    const c = new THREE.Color(color).multiplyScalar(mult);
    return track(new THREE.MeshBasicMaterial({ color: c }));
  };
  const add = (mesh: THREE.Mesh, parent: THREE.Object3D, cast = true, receive = true) => {
    mesh.castShadow = cast;
    mesh.receiveShadow = receive;
    parent.add(mesh);
    return mesh;
  };
  const box = (
    w: number,
    h: number,
    d: number,
    m: THREE.Material | THREE.Material[],
    x: number,
    y: number,
    z: number,
    parent: THREE.Object3D = scene,
    cast = true,
  ) => {
    const mesh = new THREE.Mesh(track(new THREE.BoxGeometry(w, h, d)), m);
    mesh.position.set(x, y, z);
    return add(mesh, parent, cast);
  };
  const cyl = (
    rt: number,
    rb: number,
    h: number,
    seg: number,
    m: THREE.Material,
    x: number,
    y: number,
    z: number,
    parent: THREE.Object3D = scene,
    cast = true,
  ) => {
    const mesh = new THREE.Mesh(track(new THREE.CylinderGeometry(rt, rb, h, seg)), m);
    mesh.position.set(x, y, z);
    return add(mesh, parent, cast);
  };
  const plane = (
    w: number,
    h: number,
    m: THREE.Material,
    x: number,
    y: number,
    z: number,
    parent: THREE.Object3D = scene,
  ) => {
    const mesh = new THREE.Mesh(track(new THREE.PlaneGeometry(w, h)), m);
    mesh.position.set(x, y, z);
    parent.add(mesh);
    return mesh;
  };
  const collide = (cx: number, cy: number, cz: number, w: number, h: number, d: number) =>
    colliders.push(boxFromCenter(cx, cy, cz, w, h, d));

  const glowTex = track(TX.makeGlow());
  const glowMat = (color: number, opacity: number) =>
    track(
      new THREE.MeshBasicMaterial({
        map: glowTex,
        color,
        transparent: true,
        opacity,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        fog: false,
      }),
    );

  /* ----------------------------------------------------------- materials */
  const steel = mat(0x2c3330, 0.5, 0.85);
  const darkSteel = mat(0x1b211f, 0.45, 0.85);
  const pipeMat = mat(0x3b4838, 0.55, 0.7);
  const gasMat = mat(0xb8941c, 0.5, 0.5);
  const galv = mat(0x5b6560, 0.5, 0.75);

  /* ---------------------------------------------------------------- lights */
  scene.add(new THREE.HemisphereLight(0xb8c0ae, 0x1c201b, 0.62));
  scene.add(new THREE.AmbientLight(0x434a40, 0.75));

  const spots: THREE.SpotLight[] = [];
  const tubeMats: THREE.MeshBasicMaterial[] = [];
  const SPOT_I = 120;
  const spotPos: [number, number][] = [
    [-3.6, -3.6],
    [3.6, -3.6],
    [-3.6, 3.6],
    [3.6, 3.6],
  ];

  /* ---------------------------------------------------------------- floor */
  const floorTex = TX.makeFloor();
  track(floorTex.map);
  track(floorTex.rough);
  const floor = new THREE.Mesh(
    track(new THREE.PlaneGeometry(16, 16)),
    mat(0xffffff, 1, 0.12, { map: floorTex.map, roughnessMap: floorTex.rough }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);
  // outer slab (below walls) to hide gaps
  const under = new THREE.Mesh(track(new THREE.PlaneGeometry(40, 40)), mat(0x050605, 1, 0));
  under.rotation.x = -Math.PI / 2;
  under.position.y = -0.02;
  scene.add(under);

  /* -------------------------------------------------------------- ceiling */
  const ceilTex = track(TX.makeCeiling());
  const ceiling = new THREE.Mesh(track(new THREE.PlaneGeometry(16, 16)), mat(0xffffff, 0.8, 0.4, { map: ceilTex }));
  ceiling.rotation.x = Math.PI / 2;
  ceiling.position.y = 5;
  scene.add(ceiling);

  // longitudinal I-beams
  for (const x of [-6, -2, 2, 6]) {
    box(0.32, 0.05, 16, steel, x, 4.975, 0, scene, false);
    box(0.32, 0.05, 16, steel, x, 4.625, 0, scene, false);
    box(0.06, 0.35, 16, steel, x, 4.8, 0, scene, false);
    for (let z = -7; z <= 7; z += 2) box(0.34, 0.3, 0.05, darkSteel, x, 4.8, z, scene, false);
  }
  // cross beams
  for (const z of [-6, 0, 6]) {
    box(16, 0.04, 0.2, darkSteel, 0, 4.96, z, scene, false);
    box(16, 0.04, 0.2, darkSteel, 0, 4.78, z, scene, false);
    box(16, 0.2, 0.05, darkSteel, 0, 4.87, z, scene, false);
  }
  // ventilation ducts
  for (const z of [-5.3, 5.3]) {
    box(16, 0.45, 0.75, galv, 0, 4.35, z, scene, false);
    for (let x = -7; x <= 7; x += 2) box(0.07, 0.52, 0.82, mat(0x3a423e, 0.6, 0.7), x, 4.35, z, scene, false);
  }

  // lamps (+ real spot lights + visible light shafts)
  const coneMat = (intensity: number, color: number, invert = 0) =>
    track(
      new THREE.ShaderMaterial({
        vertexShader: CONE_VS,
        fragmentShader: CONE_FS,
        uniforms: {
          uColor: { value: new THREE.Color(color) },
          uIntensity: { value: intensity },
          uInvert: { value: invert },
        },
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
      }),
    );
  const housing = mat(0x161a18, 0.6, 0.7);
  const fixture = (x: number, z: number, withLight: boolean) => {
    box(1.5, 0.1, 0.3, housing, x, 4.57, z, scene, false);
    const tm = emis(0xfff1d6, 2.2);
    tubeMats.push(tm);
    box(1.34, 0.03, 0.2, tm, x, 4.505, z, scene, false);
    for (const dx of [-0.6, 0.6]) cyl(0.012, 0.012, 0.45, 5, darkSteel, x + dx, 4.78, z, scene, false);
    if (withLight) {
      const s = new THREE.SpotLight(0xfff1d6, SPOT_I, 15, 1.05, 0.6, 2);
      s.position.set(x, 4.48, z);
      s.target.position.set(x, 0, z);
      s.shadow.bias = -0.0006;
      s.shadow.normalBias = 0.04;
      s.shadow.camera.near = 0.4;
      s.shadow.camera.far = 12;
      scene.add(s, s.target);
      spots.push(s);
      const cone = new THREE.Mesh(track(new THREE.ConeGeometry(2.1, 4.5, 32, 1, true)), coneMat(0.16, 0xffeccc));
      cone.position.set(x, 2.25, z);
      scene.add(cone);
    }
  };
  for (const [x, z] of spotPos) fixture(x, z, true);
  fixture(0, -3.6, false);
  fixture(0, 3.6, false);

  /* ----------------------------------------------------------------- walls */
  const wallTex = track(TX.makeWall());
  const wallMat = mat(0xffffff, 0.92, 0.05, { map: wallTex });
  const hazardTex = track(TX.makeHazard());
  const hazardMat = mat(0xffffff, 0.8, 0, { map: hazardTex });
  const bannerTex = track(TX.makeBanner());
  const bannerMat = mat(0xffffff, 0.95, 0, { map: bannerTex, transparent: true, alphaTest: 0.4, side: THREE.DoubleSide });
  const mapTex = track(TX.makeMap());
  const mapMat = mat(0xffffff, 0.85, 0, { map: mapTex });
  const cabTex = track(TX.makeCabinet());
  const cabMat = mat(0xffffff, 0.7, 0.3, { map: cabTex });
  const lampAmber = emis(0xffb455, 2.4);
  const ledGreen = emis(0x39ff88, 2.2);
  const ledAmber = emis(0xffb800, 2);
  const ledRed = emis(0xff3a30, 2);
  const edgeGlow = emis(0x6dffa8, 1.2);

  const screens: THREE.Mesh[] = [];
  const swayers: { o: THREE.Object3D; ph: number }[] = [];
  const screenNames = ["01 · КОМАНДНЫЙ ПУНКТ", "02 · НАСТРОЙКИ", "03 · ИНТРО", "04 · ПОЛЕВОЕ РУКОВОДСТВО"];

  const banner = (g: THREE.Group, x: number, ph: number) => {
    cyl(0.03, 0.03, 1.5, 8, darkSteel, x, 4.76, 0.1, g, false).rotation.z = Math.PI / 2;
    for (const dx of [-0.75, 0.75]) box(0.06, 0.06, 0.06, darkSteel, x + dx, 4.76, 0.1, g, false);
    const pivot = new THREE.Group();
    pivot.position.set(x, 4.72, 0.11);
    g.add(pivot);
    const b = new THREE.Mesh(track(new THREE.PlaneGeometry(1.25, 3.125)), bannerMat);
    b.position.set(0, -1.5625, 0);
    b.castShadow = true;
    pivot.add(b);
    swayers.push({ o: pivot, ph });
  };

  const mapBoard = (g: THREE.Group, x: number) => {
    box(2.7, 1.8, 0.08, mat(0x2a2f27, 0.6, 0.6), x, 2.5, 0.04, g);
    plane(2.5, 1.6, mapMat, x, 2.5, 0.086, g);
    box(1.6, 0.06, 0.14, emis(0xffd9a0, 2), x, 3.5, 0.12, g, false);
    box(1.7, 0.08, 0.16, darkSteel, x, 3.56, 0.1, g, false);
    const t = track(TX.makeSign(["ТАКТИЧЕСКАЯ КАРТА"], 640, 90, { fg: "#d6d6bc", bg: "#1b211f", border: "#8a9a6a", spacing: 5, size: 38 }));
    plane(1.7, 0.24, mat(0xffffff, 0.7, 0, { map: t }), x, 1.44, 0.06, g);
  };

  const cabinet = (g: THREE.Group, x: number) => {
    box(1.1, 1.7, 0.35, mat(0x3d4637, 0.6, 0.5), x, 1.0, 0.175, g);
    plane(1.0, 1.5, cabMat, x, 1.0, 0.352, g);
    box(0.06, 0.2, 0.05, darkSteel, x + 0.36, 1.0, 0.375, g, false);
    [ledGreen, ledAmber, ledRed].forEach((m, k) => box(0.05, 0.05, 0.02, m, x - 0.3 + k * 0.1, 1.72, 0.36, g, false));
    cyl(0.04, 0.04, 3.1, 8, pipeMat, x - 0.3, 3.4, 0.12, g, false);
    cyl(0.04, 0.04, 3.1, 8, pipeMat, x - 0.18, 3.4, 0.12, g, false);
  };

  const wallLamp = (g: THREE.Group, x: number, y: number) => {
    box(0.1, 0.1, 0.16, darkSteel, x, y, 0.08, g, false);
    box(0.34, 0.28, 0.2, housing, x, y, 0.2, g, false);
    box(0.26, 0.2, 0.04, lampAmber, x, y, 0.311, g, false);
    for (const dx of [-0.09, 0, 0.09]) box(0.012, 0.28, 0.012, darkSteel, x + dx, y, 0.325, g, false);
    plane(1.7, 1.7, glowMat(0xffa850, 0.55), x, y, 0.34, g);
  };

  const pipes = (g: THREE.Group) => {
    cyl(0.085, 0.085, 16, 14, pipeMat, 0, 4.72, 0.22, g, false).rotation.z = Math.PI / 2;
    cyl(0.055, 0.055, 16, 12, gasMat, 0, 4.9, 0.18, g, false).rotation.z = Math.PI / 2;
    for (let x = -7; x <= 7; x += 2) {
      box(0.06, 0.34, 0.06, darkSteel, x, 4.8, 0.12, g, false);
      box(0.12, 0.03, 0.2, darkSteel, x, 4.72, 0.16, g, false);
      cyl(0.095, 0.095, 0.05, 12, darkSteel, x + 1, 4.72, 0.22, g, false).rotation.z = Math.PI / 2;
    }
    for (const sx of [-1, 1]) {
      box(4.6, 0.04, 0.26, darkSteel, sx * 5.8, 4.3, 0.16, g, false);
      box(4.6, 0.1, 0.03, darkSteel, sx * 5.8, 4.34, 0.29, g, false);
      cyl(0.045, 0.045, 4.5, 8, mat(0x111312, 0.9), sx * 5.8, 4.35, 0.18, g, false).rotation.z = Math.PI / 2;
      cyl(0.035, 0.035, 4.5, 8, mat(0x7a1c16, 0.9), sx * 5.8, 4.37, 0.24, g, false).rotation.z = Math.PI / 2;
      cyl(0.05, 0.05, 4.7, 8, pipeMat, sx * 7.7, 2.65, 0.14, g, false);
    }
  };

  const buildWall = (i: number) => {
    const w = WALLS[i];
    const n = wallNormal(i);
    const g = new THREE.Group();
    g.position.set(w.x, 0, w.z);
    g.rotation.y = w.rotY;
    scene.add(g);

    const wm = new THREE.Mesh(track(new THREE.PlaneGeometry(16, 5)), wallMat);
    wm.position.set(0, 2.5, 0);
    wm.receiveShadow = true;
    g.add(wm);
    plane(16, 0.14, hazardMat, 0, 0.07, 0.006, g);
    box(16, 0.07, 0.07, darkSteel, 0, 1.2, 0.035, g, false);

    // monitor bezel
    const T = 0.2;
    const D = 0.14;
    const bz = mat(0x1b211f, 0.45, 0.85);
    box(SCREEN_W + 2 * T, T, D, bz, 0, SCREEN_CY + SCREEN_H / 2 + T / 2, D / 2, g);
    box(SCREEN_W + 2 * T, T, D, bz, 0, SCREEN_CY - SCREEN_H / 2 - T / 2, D / 2, g);
    for (const sx of [-1, 1]) box(T, SCREEN_H, D, bz, sx * (SCREEN_W / 2 + T / 2), SCREEN_CY, D / 2, g);
    // glowing inner lip
    const lipZ = D + 0.002;
    box(SCREEN_W + 0.1, 0.022, 0.01, edgeGlow, 0, SCREEN_CY + SCREEN_H / 2 + 0.03, lipZ, g, false);
    box(SCREEN_W + 0.1, 0.022, 0.01, edgeGlow, 0, SCREEN_CY - SCREEN_H / 2 - 0.03, lipZ, g, false);
    for (const sx of [-1, 1]) box(0.022, SCREEN_H + 0.1, 0.01, edgeGlow, sx * (SCREEN_W / 2 + 0.03), SCREEN_CY, lipZ, g, false);
    // bolts
    for (const sx of [-1, 1]) {
      for (const sy of [-1, 1]) {
        cyl(0.035, 0.035, 0.03, 8, steel, sx * (SCREEN_W / 2 + T / 2), SCREEN_CY + sy * (SCREEN_H / 2 + T / 2), D + 0.012, g, false).rotation.x = Math.PI / 2;
      }
    }
    // status LEDs on the bottom bezel
    [ledGreen, ledAmber].forEach((m, k) => box(0.06, 0.04, 0.012, m, SCREEN_W / 2 - 0.2 - k * 0.14, SCREEN_CY - SCREEN_H / 2 - T / 2, D + 0.006, g, false));

    // the screen itself
    const sm = new THREE.Mesh(
      track(new THREE.PlaneGeometry(SCREEN_W, SCREEN_H)),
      track(new THREE.MeshBasicMaterial({ map: screenTex[i], toneMapped: false, fog: false, color: new THREE.Color(1.08, 1.08, 1.08) })),
    );
    sm.position.set(0, SCREEN_CY, 0.078);
    sm.userData.screen = i;
    g.add(sm);
    screens.push(sm);

    // label plate
    const lt = track(TX.makeSign([screenNames[i]], 1024, 110, { fg: "#d8f3e0", bg: "#101a15", border: "#6dffa8", spacing: 6, size: 52, font: TX.FONT_DISPLAY }));
    plane(
      4.4,
      0.472,
      mat(0xffffff, 0.6, 0, { map: lt, emissive: 0x2a5a40, emissiveMap: lt, emissiveIntensity: 0.6 }),
      0,
      4.42,
      0.03,
      g,
    );

    // floor glow strip under monitor
    box(SCREEN_W + 0.6, 0.02, 0.06, edgeGlow, 0, 0.012, 0.34, g, false);
    plane(11, 7, glowMat(0x2fff8a, 0.085), 0, SCREEN_CY, 0.014, g);
    plane(8, 1.6, glowMat(0x2fff8a, 0.13), 0, 0.025, 0.8, g).rotation.x = -Math.PI / 2;

    pipes(g);
    for (const sx of [-1, 1]) wallLamp(g, sx * 4.5, 3.75);

    // decoration, arranged so that monitors remain the focus
    if (i === 0) {
      mapBoard(g, -5.7);
      banner(g, 5.7, 0);
    } else if (i === 1) {
      cabinet(g, -5.7);
      banner(g, 5.7, 1.7);
    } else if (i === 2) {
      banner(g, -5.7, 3.1);
      mapBoard(g, 5.7);
    } else {
      banner(g, -5.7, 4.6);
      cabinet(g, 5.7);
    }

    // wash light cast by the monitor onto the room
    const rl = new THREE.RectAreaLight(0x7dffb4, 2.3, SCREEN_W, SCREEN_H);
    const lp = new THREE.Vector3(w.x + n.x * 0.35, SCREEN_CY, w.z + n.z * 0.35);
    rl.position.copy(lp);
    rl.lookAt(lp.clone().add(n));
    scene.add(rl);
  };
  for (let i = 0; i < 4; i++) buildWall(i);

  /* ---------------------------------------------------------------- crates */
  const crate = (
    x: number,
    z: number,
    w: number,
    h: number,
    d: number,
    label: string,
    sub: string,
    seed: number,
    y0 = 0,
  ) => {
    const tex = track(TX.makeCrate(label, sub, seed));
    const m = mat(0xffffff, 0.85, 0, { map: tex });
    const cy = y0 + h / 2;
    box(w, h, d, m, x, cy, z);
    const post = mat(0x20271b, 0.6, 0.6);
    for (const sx of [-1, 1]) {
      for (const sz of [-1, 1]) box(0.09, h + 0.02, 0.09, post, x + (sx * w) / 2, cy, z + (sz * d) / 2);
    }
    box(w + 0.04, 0.05, d + 0.04, post, x, y0 + h - 0.02, z);
    box(w + 0.04, 0.05, d + 0.04, post, x, y0 + 0.03, z);
    for (const sx of [-1, 1]) box(0.05, 0.07, 0.34, darkSteel, x + (sx * (w + 0.02)) / 2, cy + h * 0.2, z);
    collide(x, cy, z, w, h, d);
  };
  crate(-6.8, 5.5, 1.3, 1.1, 1.3, "БОЕПРИПАСЫ", "ВЗРЫВООПАСНО", 101);
  crate(-6.8, 5.5, 1.0, 0.3, 1.0, "ЗИП", "ЗАПЧАСТИ", 102, 1.1);
  crate(6.8, 5.5, 1.3, 1.1, 1.3, "ПАЙКИ", "ПРОДОВОЛЬСТВИЕ", 103);
  crate(6.8, 5.5, 1.0, 0.3, 1.0, "МЕД", "АПТЕЧКИ", 104, 1.1);
  crate(-4.9, 7.0, 0.7, 0.7, 0.7, "СВЯЗЬ", "РАДИО", 105);
  crate(4.9, 7.0, 0.7, 0.7, 0.7, "ИНСТР", "ИНВЕНТАРЬ", 106);

  /* --------------------------------------------------------------- barrels */
  const barrelTex = track(TX.makeBarrel(7));
  const barrelMat = mat(0xffffff, 0.55, 0.45, { map: barrelTex });
  for (const [x, z] of [
    [-7.0, -6.9],
    [-6.25, -7.05],
    [-7.05, -6.15],
  ]) {
    cyl(0.3, 0.3, 0.95, 24, barrelMat, x, 0.475, z);
    cyl(0.31, 0.31, 0.04, 24, darkSteel, x, 0.95, z, scene, false);
    collide(x, 0.475, z, 0.6, 0.95, 0.6);
  }

  /* -------------------------------------------------------------- sandbags */
  const burlapTex = track(TX.makeBurlap());
  const bagGeo = track(new RoundedBoxGeometry(0.56, 0.22, 0.36, 3, 0.07));
  const bagMat = mat(0xffffff, 0.95, 0, { map: burlapTex });
  const bagDefs: { x: number; z: number; ry: number; layer: number }[] = [];
  const rnd = TX.rng(99);
  for (const [sx, sz] of [
    [1, -1],
    [-1, 1],
  ]) {
    for (let layer = 0; layer < 3; layer++) {
      const odd = layer % 2 === 1;
      const nA = odd ? 4 : 5;
      for (let k = 0; k < nA; k++) {
        bagDefs.push({ x: sx * (5.2 + 0.56 * k + (odd ? 0.28 : 0)), z: sz * 7.25, ry: (rnd() - 0.5) * 0.12, layer });
      }
      const nB = odd ? 3 : 4;
      for (let k = 0; k < nB; k++) {
        bagDefs.push({
          x: sx * 7.25,
          z: sz * (6.62 - 0.56 * k - (odd ? 0.28 : 0)),
          ry: Math.PI / 2 + (rnd() - 0.5) * 0.12,
          layer,
        });
      }
    }
    collide(sx * 6.32, 0.33, sz * 7.25, 2.9, 0.66, 0.42);
    collide(sx * 7.25, 0.33, sz * 5.8, 0.42, 0.66, 2.3);
  }
  const bags = new THREE.InstancedMesh(bagGeo, bagMat, bagDefs.length);
  const dummy = new THREE.Object3D();
  bagDefs.forEach((b, idx) => {
    dummy.position.set(b.x, 0.11 + 0.21 * b.layer, b.z);
    dummy.rotation.set(0, b.ry, 0);
    dummy.scale.set(0.95 + rnd() * 0.1, 0.9 + rnd() * 0.2, 0.95 + rnd() * 0.1);
    dummy.updateMatrix();
    bags.setMatrixAt(idx, dummy.matrix);
    const v = 0.85 + rnd() * 0.3;
    bags.setColorAt(idx, new THREE.Color(v, v * 0.97, v * 0.9));
  });
  bags.castShadow = true;
  bags.receiveShadow = true;
  scene.add(bags);

  /* -------------------------------------------------------- holo war-table */
  const holoRoot = new THREE.Group();
  scene.add(holoRoot);
  const holoGreen = 0x5dffa0;
  cyl(1.15, 1.2, 0.08, 48, darkSteel, 0, 0.04, 0, holoRoot, false);
  cyl(0.92, 0.95, 0.03, 48, mat(0x0a1510, 0.3, 0.6), 0, 0.095, 0, holoRoot, false);
  const rim = new THREE.Mesh(track(new THREE.TorusGeometry(1.03, 0.022, 8, 96)), emis(holoGreen, 1.8));
  rim.rotation.x = Math.PI / 2;
  rim.position.y = 0.1;
  holoRoot.add(rim);
  const rim2 = new THREE.Mesh(track(new THREE.TorusGeometry(0.62, 0.012, 8, 72)), emis(holoGreen, 1.4));
  rim2.rotation.x = Math.PI / 2;
  rim2.position.y = 0.11;
  holoRoot.add(rim2);
  cyl(0.2, 0.26, 0.06, 24, darkSteel, 0, 0.13, 0, holoRoot, false);
  cyl(0.15, 0.15, 0.02, 24, emis(0xb8ffd2, 2.4), 0, 0.165, 0, holoRoot, false);

  const holo = new THREE.Group();
  holo.position.y = 1.22;
  holoRoot.add(holo);
  const wire = new THREE.Mesh(
    track(new THREE.SphereGeometry(0.55, 28, 18)),
    track(new THREE.MeshBasicMaterial({ color: holoGreen, wireframe: true, transparent: true, opacity: 0.38, depthWrite: false, blending: THREE.AdditiveBlending })),
  );
  holo.add(wire);
  const core = new THREE.Mesh(
    track(new THREE.SphereGeometry(0.53, 24, 16)),
    track(new THREE.MeshBasicMaterial({ color: 0x2fe08a, transparent: true, opacity: 0.1, depthWrite: false, blending: THREE.AdditiveBlending })),
  );
  holo.add(core);
  const rings: THREE.Mesh[] = [];
  for (const [r, tx, tz] of [
    [0.74, 0.35, 0],
    [0.88, -0.5, 0.4],
    [0.66, 1.1, -0.3],
  ]) {
    const ring = new THREE.Mesh(track(new THREE.TorusGeometry(r, 0.007, 6, 90)), emis(0xb8ffd2, 1.8));
    ring.rotation.set(tx, 0, tz);
    holo.add(ring);
    rings.push(ring);
  }
  const blips: THREE.Mesh[] = [];
  const blipMat = emis(0xffc247, 2.4);
  const blipGeo = track(new THREE.SphereGeometry(0.02, 8, 8));
  for (let k = 0; k < 14; k++) {
    const phi = Math.acos(1 - 2 * ((k + 0.5) / 14));
    const th = Math.PI * (1 + Math.sqrt(5)) * k;
    const b = new THREE.Mesh(blipGeo, blipMat);
    b.position.set(Math.cos(th) * Math.sin(phi) * 0.55, Math.cos(phi) * 0.55, Math.sin(th) * Math.sin(phi) * 0.55);
    wire.add(b);
    blips.push(b);
  }
  const beam = new THREE.Mesh(track(new THREE.CylinderGeometry(0.5, 0.88, 1.2, 40, 1, true)), coneMat(0.22, holoGreen, 1));
  beam.position.y = 0.72;
  holoRoot.add(beam);
  const holoLight = new THREE.PointLight(0x58ffaa, 6, 8, 2);
  holoLight.position.set(0, 1.25, 0);
  scene.add(holoLight);

  /* ------------------------------------------------------------------ dust */
  const N = 420;
  const dpos = new Float32Array(N * 3);
  const dseed = new Float32Array(N);
  for (let k = 0; k < N; k++) {
    dpos[k * 3] = (rnd() - 0.5) * 15;
    dpos[k * 3 + 1] = 0.2 + rnd() * 4.6;
    dpos[k * 3 + 2] = (rnd() - 0.5) * 15;
    dseed[k] = rnd() * 100;
  }
  const dgeo = track(new THREE.BufferGeometry());
  dgeo.setAttribute("position", new THREE.BufferAttribute(dpos, 3));
  const dust = new THREE.Points(
    dgeo,
    track(
      new THREE.PointsMaterial({
        size: 0.028,
        map: glowTex,
        color: 0xd7ecdc,
        transparent: true,
        opacity: 0.42,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    ),
  );
  dust.frustumCulled = false;
  scene.add(dust);

  /* --------------------------------------------------------------- runtime */
  const baseTube = new THREE.Color(0xfff1d6).multiplyScalar(2.2);
  const setShadows = (level: 0 | 1 | 2) => {
    const size = level === 2 ? 2048 : 1024;
    spots.forEach((s, idx) => {
      const want = level === 2 || (level === 1 && idx % 2 === 0);
      if (s.castShadow !== want || s.shadow.mapSize.x !== size) {
        s.castShadow = want;
        s.shadow.mapSize.set(size, size);
        s.shadow.map?.dispose();
        s.shadow.map = null;
      }
    });
  };

  const update = (t: number, dt: number) => {
    holo.rotation.y = t * 0.45;
    rings.forEach((r, k) => {
      r.rotation.y = t * (0.6 + k * 0.25) * (k % 2 ? -1 : 1);
    });
    wire.rotation.y = -t * 0.2;
    blips.forEach((b, k) => b.scale.setScalar(0.8 + 0.6 * Math.abs(Math.sin(t * 2 + k))));
    holo.position.y = 1.22 + Math.sin(t * 1.2) * 0.03;
    holoLight.intensity = 5.6 + Math.sin(t * 9) * 0.4 + Math.sin(t * 23) * 0.3;
    rim2.rotation.z = t * 0.5;

    swayers.forEach((s) => {
      s.o.rotation.x = Math.sin(t * 0.7 + s.ph) * 0.012;
    });

    // one lamp flickers like an old bunker fixture
    const burst = Math.sin(t * 0.55) > 0.82 ? (Math.sin(t * 41) * Math.sin(t * 17.3) > 0.15 ? 0.25 : 1) : 1;
    if (spots[3]) spots[3].intensity = SPOT_I * burst;
    tubeMats[3]?.color.copy(baseTube).multiplyScalar(0.35 + 0.65 * burst);

    const p = dgeo.attributes.position as THREE.BufferAttribute;
    for (let k = 0; k < N; k++) {
      let y = p.getY(k) + dt * (0.03 + 0.02 * Math.sin(dseed[k]));
      if (y > 4.9) y = 0.2;
      p.setY(k, y);
      p.setX(k, p.getX(k) + Math.sin(t * 0.3 + dseed[k]) * dt * 0.05);
      p.setZ(k, p.getZ(k) + Math.cos(t * 0.27 + dseed[k]) * dt * 0.05);
    }
    p.needsUpdate = true;
  };

  const dispose = () => {
    scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh && m.geometry) m.geometry.dispose();
    });
    bags.dispose();
    disposables.forEach((d) => d.dispose());
  };

  return { scene, screens, colliders, update, setShadows, dispose };
}
