import * as THREE from "three";

export const FONT_DISPLAY = '"Russo One", "Oswald", Impact, "Arial Black", sans-serif';
export const FONT_MONO = '"JetBrains Mono", "Consolas", "Courier New", monospace';

type Ctx = CanvasRenderingContext2D;
type Rand = () => number;

export function rng(seed: number): Rand {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function mk(w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;
  return { c, ctx };
}

function toTex(c: HTMLCanvasElement, srgb = true, repeat?: [number, number]) {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  if (repeat) t.repeat.set(repeat[0], repeat[1]);
  return t;
}

function grain(ctx: Ctx, w: number, h: number, rand: Rand, amount: number) {
  const img = ctx.getImageData(0, 0, w, h);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (rand() - 0.5) * amount;
    d[i] += n;
    d[i + 1] += n;
    d[i + 2] += n;
  }
  ctx.putImageData(img, 0, 0);
}

function blotches(
  ctx: Ctx,
  w: number,
  h: number,
  rand: Rand,
  count: number,
  rmin: number,
  rmax: number,
  rgb: string,
  alpha: number,
  yr: [number, number] = [0, 1],
) {
  for (let i = 0; i < count; i++) {
    const x = rand() * w;
    const y = (yr[0] + rand() * (yr[1] - yr[0])) * h;
    const r = rmin + rand() * (rmax - rmin);
    const a = alpha * (0.4 + rand() * 0.6);
    for (const ox of [-w, 0, w]) {
      const cx = x + ox;
      if (cx + r < 0 || cx - r > w) continue;
      const g = ctx.createRadialGradient(cx, y, 0, cx, y, r);
      g.addColorStop(0, `rgba(${rgb},${a})`);
      g.addColorStop(1, `rgba(${rgb},0)`);
      ctx.fillStyle = g;
      ctx.fillRect(cx - r, y - r, r * 2, r * 2);
    }
  }
}

export function spaced(
  ctx: Ctx,
  text: string,
  x: number,
  y: number,
  spacing: number,
  align: "left" | "center" | "right" = "left",
) {
  const chars = Array.from(text);
  const widths = chars.map((ch) => ctx.measureText(ch).width);
  const total = widths.reduce((a, b) => a + b, 0) + spacing * Math.max(0, chars.length - 1);
  let cx = align === "center" ? x - total / 2 : align === "right" ? x - total : x;
  const prev = ctx.textAlign;
  ctx.textAlign = "left";
  chars.forEach((ch, i) => {
    ctx.fillText(ch, cx, y);
    cx += widths[i] + spacing;
  });
  ctx.textAlign = prev;
}

export function starPath(ctx: Ctx, cx: number, cy: number, ro: number, ri: number, rot = -Math.PI / 2) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const r = i % 2 === 0 ? ro : ri;
    const a = rot + (i * Math.PI) / 5;
    const px = cx + Math.cos(a) * r;
    const py = cy + Math.sin(a) * r;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

/* ------------------------------------------------------------------ FLOOR */

export function makeFloor() {
  const S = 2048;
  const P = S / 16; // px per metre
  const rand = rng(11);
  const { c, ctx } = mk(S, S);
  ctx.fillStyle = "#3b3f39";
  ctx.fillRect(0, 0, S, S);

  const slab = 2 * P;
  for (let i = 0; i < 8; i++) {
    for (let j = 0; j < 8; j++) {
      const v = (rand() - 0.5) * 0.14;
      ctx.fillStyle = v > 0 ? `rgba(255,255,240,${v})` : `rgba(0,0,0,${-v})`;
      ctx.fillRect(i * slab, j * slab, slab, slab);
    }
  }
  blotches(ctx, S, S, rand, 90, 60, 260, "18,20,16", 0.2);
  blotches(ctx, S, S, rand, 60, 60, 220, "150,155,135", 0.07);

  // expansion joints
  for (let k = 0; k <= 8; k++) {
    ctx.strokeStyle = "rgba(6,8,6,0.8)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(k * slab, 0);
    ctx.lineTo(k * slab, S);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, k * slab);
    ctx.lineTo(S, k * slab);
    ctx.stroke();
    ctx.strokeStyle = "rgba(255,255,240,0.06)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(k * slab + 3, 0);
    ctx.lineTo(k * slab + 3, S);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, k * slab + 3);
    ctx.lineTo(S, k * slab + 3);
    ctx.stroke();
  }

  const wx = (x: number) => (x + 8) * P;
  const wz = (z: number) => (z + 8) * P;

  // yellow corner brackets
  ctx.strokeStyle = "rgba(222,184,52,0.88)";
  ctx.lineWidth = 0.1 * P;
  ctx.lineCap = "butt";
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const cx = sx * 6.6;
      const cz = sz * 6.6;
      ctx.beginPath();
      ctx.moveTo(wx(cx - sx * 1.3), wz(cz));
      ctx.lineTo(wx(cx), wz(cz));
      ctx.lineTo(wx(cx), wz(cz - sz * 1.3));
      ctx.stroke();
    }
  }

  // lanes + chevrons + labels pointing to every monitor
  const labels = ["01 · КОМАНДНЫЙ ПУНКТ", "02 · НАСТРОЙКИ", "03 · ИНТРО", "04 · РУКОВОДСТВО"];
  const angles = [0, Math.PI / 2, Math.PI, -Math.PI / 2];
  for (let i = 0; i < 4; i++) {
    ctx.save();
    ctx.translate(wx(0), wz(0));
    ctx.rotate(angles[i]);
    // after rotate: canvas "up" (negative y) points to monitor i
    ctx.strokeStyle = "rgba(216,220,192,0.55)";
    ctx.lineWidth = 0.08 * P;
    ctx.setLineDash([0.4 * P, 0.3 * P]);
    ctx.beginPath();
    ctx.moveTo(0, -2.9 * P);
    ctx.lineTo(0, -5.2 * P);
    ctx.stroke();
    ctx.setLineDash([]);
    for (const d of [5.45, 5.8]) {
      ctx.beginPath();
      ctx.moveTo(-0.5 * P, -(d - 0.3) * P);
      ctx.lineTo(0, -d * P);
      ctx.lineTo(0.5 * P, -(d - 0.3) * P);
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(216,220,192,0.6)";
    ctx.font = `${0.2 * P}px ${FONT_DISPLAY}`;
    ctx.textAlign = "center";
    spaced(ctx, labels[i], 0, -6.5 * P, 4, "center");
    ctx.restore();
  }

  // central emblem
  ctx.save();
  ctx.translate(wx(0), wz(0));
  ctx.strokeStyle = "rgba(201,207,176,0.72)";
  ctx.lineWidth = 0.09 * P;
  ctx.beginPath();
  ctx.arc(0, 0, 2.3 * P, 0, Math.PI * 2);
  ctx.stroke();
  ctx.lineWidth = 0.03 * P;
  ctx.beginPath();
  ctx.arc(0, 0, 2.05 * P, 0, Math.PI * 2);
  ctx.stroke();
  ctx.lineWidth = 0.025 * P;
  for (let a = 0; a < 360; a += 5) {
    const r = (a % 45 === 0 ? 0.28 : 0.12) * P;
    const rad = (a * Math.PI) / 180;
    ctx.beginPath();
    ctx.moveTo(Math.cos(rad) * 2.42 * P, Math.sin(rad) * 2.42 * P);
    ctx.lineTo(Math.cos(rad) * (2.42 * P + r), Math.sin(rad) * (2.42 * P + r));
    ctx.stroke();
  }
  ctx.setLineDash([0.18 * P, 0.14 * P]);
  ctx.lineWidth = 0.03 * P;
  ctx.beginPath();
  ctx.arc(0, 0, 1.7 * P, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);
  starPath(ctx, 0, 0, 1.4 * P, 0.56 * P);
  ctx.fillStyle = "rgba(185,190,150,0.5)";
  ctx.fill();
  ctx.lineWidth = 0.03 * P;
  ctx.stroke();
  ctx.restore();

  // wear: oil, cracks, scuffs
  blotches(ctx, S, S, rand, 14, 20, 70, "4,5,4", 0.3);
  ctx.lineCap = "round";
  for (let i = 0; i < 16; i++) {
    let x = rand() * S;
    let y = rand() * S;
    let a = rand() * Math.PI * 2;
    ctx.strokeStyle = `rgba(8,9,7,${0.35 + rand() * 0.3})`;
    ctx.lineWidth = 1 + rand() * 1.8;
    ctx.beginPath();
    ctx.moveTo(x, y);
    for (let s = 0; s < 34; s++) {
      a += (rand() - 0.5) * 0.9;
      x += Math.cos(a) * 12;
      y += Math.sin(a) * 12;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  for (let i = 0; i < 260; i++) {
    const x = rand() * S;
    const y = rand() * S;
    const a = rand() * Math.PI;
    const l = 20 + rand() * 60;
    ctx.strokeStyle = `rgba(230,230,210,${0.03 + rand() * 0.05})`;
    ctx.lineWidth = 1 + rand() * 2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l);
    ctx.stroke();
  }
  grain(ctx, S, S, rand, 26);

  // roughness map: wet/glossy patches reflect the monitors
  const R = mk(1024, 1024);
  R.ctx.fillStyle = "#9c9c9c";
  R.ctx.fillRect(0, 0, 1024, 1024);
  blotches(R.ctx, 1024, 1024, rand, 26, 40, 150, "70,70,70", 0.55);
  blotches(R.ctx, 1024, 1024, rand, 40, 30, 120, "230,230,230", 0.3);
  grain(R.ctx, 1024, 1024, rand, 34);

  return { map: toTex(c, true), rough: toTex(R.c, false) };
}

/* ------------------------------------------------------------------- WALL */

export function makeWall() {
  const W = 1024;
  const H = 1280;
  const P = 256;
  const rand = rng(5);
  const { c, ctx } = mk(W, H);
  const wain = H - 1.2 * P;

  ctx.fillStyle = "#4a5745";
  ctx.fillRect(0, 0, W, H);
  const g = ctx.createLinearGradient(0, 0, 0, wain);
  g.addColorStop(0, "rgba(10,14,9,0.35)");
  g.addColorStop(0.5, "rgba(10,14,9,0)");
  g.addColorStop(1, "rgba(10,14,9,0.1)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, wain);
  ctx.fillStyle = "#2b3528";
  ctx.fillRect(0, wain, W, H - wain);

  // plate tone variation
  const rows = [0, 530, wain, H];
  for (let i = 0; i < 4; i++) {
    for (let r = 0; r < 3; r++) {
      const v = (rand() - 0.5) * 0.12;
      ctx.fillStyle = v > 0 ? `rgba(255,255,230,${v})` : `rgba(0,0,0,${-v})`;
      ctx.fillRect(i * P, rows[r], P, rows[r + 1] - rows[r]);
    }
  }

  // khaki stripe between wainscot and upper wall
  ctx.fillStyle = "rgba(0,0,0,0.5)";
  ctx.fillRect(0, wain + 4, W, 6);
  ctx.fillStyle = "#98a577";
  ctx.fillRect(0, wain - 6, W, 8);
  ctx.fillStyle = "rgba(255,255,255,0.12)";
  ctx.fillRect(0, wain - 6, W, 2);

  // seams + rivets
  for (let i = 0; i < 4; i++) {
    const x = i * P;
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillRect(x - 2, 0, 4, H);
    ctx.fillStyle = "rgba(255,255,255,0.1)";
    ctx.fillRect(x + 2, 0, 1.5, H);
    for (let y = 30; y < H; y += 58) {
      for (const dx of [-14, 14]) {
        ctx.fillStyle = "rgba(0,0,0,0.5)";
        ctx.beginPath();
        ctx.arc(x + dx + 1, y + 1, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#59664f";
        ctx.beginPath();
        ctx.arc(x + dx, y, 3.4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "rgba(255,255,255,0.25)";
        ctx.beginPath();
        ctx.arc(x + dx - 1, y - 1, 1.2, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
  ctx.fillStyle = "rgba(0,0,0,0.4)";
  ctx.fillRect(0, 528, W, 3);
  ctx.fillRect(0, 0, W, 3);

  // streaks, rust, damp
  for (let i = 0; i < 70; i++) {
    const x = rand() * W;
    const y = rand() * H * 0.7;
    const len = 80 + rand() * 240;
    const wd = 5 + rand() * 18;
    const grd = ctx.createLinearGradient(0, y, 0, y + len);
    grd.addColorStop(0, `rgba(8,10,6,${0.08 + rand() * 0.1})`);
    grd.addColorStop(1, "rgba(8,10,6,0)");
    ctx.fillStyle = grd;
    ctx.fillRect(x, y, wd, len);
  }
  blotches(ctx, W, H, rand, 28, 30, 90, "125,72,36", 0.14, [0.6, 1]);
  blotches(ctx, W, H, rand, 40, 60, 220, "10,14,9", 0.2);
  blotches(ctx, W, H, rand, 24, 60, 200, "180,190,150", 0.05);
  grain(ctx, W, H, rand, 18);

  return toTex(c, true, [4, 1]);
}

export function makeCeiling() {
  const rand = rng(9);
  const { c, ctx } = mk(512, 512);
  ctx.fillStyle = "#1d221f";
  ctx.fillRect(0, 0, 512, 512);
  for (let x = 0; x < 512; x += 32) {
    const g = ctx.createLinearGradient(x, 0, x + 32, 0);
    g.addColorStop(0, "rgba(255,255,255,0.07)");
    g.addColorStop(0.5, "rgba(0,0,0,0.25)");
    g.addColorStop(1, "rgba(255,255,255,0.05)");
    ctx.fillStyle = g;
    ctx.fillRect(x, 0, 32, 512);
  }
  ctx.fillStyle = "rgba(0,0,0,0.5)";
  ctx.fillRect(0, 254, 512, 4);
  ctx.fillRect(0, 0, 512, 3);
  blotches(ctx, 512, 512, rand, 18, 40, 140, "5,6,5", 0.3);
  grain(ctx, 512, 512, rand, 14);
  return toTex(c, true, [8, 8]);
}

export function makeHazard() {
  const { c, ctx } = mk(256, 64);
  ctx.fillStyle = "#14140e";
  ctx.fillRect(0, 0, 256, 64);
  ctx.fillStyle = "#d8a81c";
  for (let x = -128; x < 384; x += 64) {
    ctx.beginPath();
    ctx.moveTo(x, 64);
    ctx.lineTo(x + 32, 64);
    ctx.lineTo(x + 32 + 64, 0);
    ctx.lineTo(x + 64, 0);
    ctx.closePath();
    ctx.fill();
  }
  const rand = rng(3);
  blotches(ctx, 256, 64, rand, 10, 8, 30, "0,0,0", 0.3);
  grain(ctx, 256, 64, rand, 30);
  return toTex(c, true, [28, 1]);
}

/* ------------------------------------------------------------------ PROPS */

export function makeCrate(label: string, sub: string, seed: number) {
  const S = 512;
  const rand = rng(seed);
  const { c, ctx } = mk(S, S);
  ctx.fillStyle = "#4d5a33";
  ctx.fillRect(0, 0, S, S);
  const planks = 6;
  const ph = S / planks;
  for (let i = 0; i < planks; i++) {
    const v = (rand() - 0.5) * 0.18;
    ctx.fillStyle = v > 0 ? `rgba(255,255,200,${v})` : `rgba(0,0,0,${-v})`;
    ctx.fillRect(0, i * ph, S, ph);
    for (let k = 0; k < 14; k++) {
      const y = i * ph + rand() * ph;
      ctx.strokeStyle = `rgba(0,0,0,${0.05 + rand() * 0.1})`;
      ctx.lineWidth = 1 + rand();
      ctx.beginPath();
      ctx.moveTo(rand() * 60, y);
      ctx.lineTo(S - rand() * 60, y + (rand() - 0.5) * 6);
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillRect(0, i * ph - 1.5, S, 3);
  }
  // frame + brace
  ctx.strokeStyle = "#2c3520";
  ctx.lineWidth = 34;
  ctx.strokeRect(17, 17, S - 34, S - 34);
  ctx.strokeStyle = "rgba(255,255,220,0.07)";
  ctx.lineWidth = 2;
  ctx.strokeRect(36, 36, S - 72, S - 72);
  ctx.strokeStyle = "#323d24";
  ctx.lineWidth = 26;
  ctx.beginPath();
  ctx.moveTo(34, 34);
  ctx.lineTo(S - 34, S - 34);
  ctx.stroke();
  for (const [x, y] of [
    [34, 34],
    [S - 34, 34],
    [34, S - 34],
    [S - 34, S - 34],
  ]) {
    ctx.fillStyle = "#171c11";
    ctx.beginPath();
    ctx.arc(x, y, 8, 0, Math.PI * 2);
    ctx.fill();
  }
  // stencil
  ctx.fillStyle = "rgba(232,230,200,0.88)";
  ctx.textAlign = "center";
  ctx.font = `46px ${FONT_DISPLAY}`;
  spaced(ctx, label, S / 2, 244, 3, "center");
  ctx.font = `bold 22px ${FONT_MONO}`;
  spaced(ctx, sub, S / 2, 288, 3, "center");
  ctx.fillRect(110, 306, 292, 5);
  ctx.font = `bold 20px ${FONT_MONO}`;
  spaced(ctx, `№ ${4000 + Math.floor(rand() * 5000)}-К`, S / 2, 346, 2, "center");
  // weathering
  blotches(ctx, S, S, rand, 14, 30, 120, "6,8,4", 0.25);
  grain(ctx, S, S, rand, 24);
  return toTex(c, true);
}

export function makeBarrel(seed: number) {
  const rand = rng(seed);
  const { c, ctx } = mk(256, 256);
  ctx.fillStyle = "#4a5130";
  ctx.fillRect(0, 0, 256, 256);
  for (const y of [14, 128, 242]) {
    const g = ctx.createLinearGradient(0, y - 10, 0, y + 10);
    g.addColorStop(0, "rgba(0,0,0,0.5)");
    g.addColorStop(0.5, "rgba(255,255,255,0.2)");
    g.addColorStop(1, "rgba(0,0,0,0.5)");
    ctx.fillStyle = g;
    ctx.fillRect(0, y - 10, 256, 20);
  }
  ctx.fillStyle = "#d8a81c";
  ctx.fillRect(0, 150, 256, 14);
  ctx.fillStyle = "rgba(232,230,200,0.9)";
  ctx.font = `34px ${FONT_DISPLAY}`;
  ctx.textAlign = "center";
  spaced(ctx, "ГСМ", 64, 100, 4, "center");
  spaced(ctx, "ГСМ", 192, 100, 4, "center");
  blotches(ctx, 256, 256, rand, 10, 20, 70, "6,8,4", 0.3);
  blotches(ctx, 256, 256, rand, 8, 10, 40, "125,72,36", 0.25);
  grain(ctx, 256, 256, rand, 22);
  return toTex(c, true);
}

export function makeBurlap() {
  const rand = rng(21);
  const { c, ctx } = mk(128, 128);
  ctx.fillStyle = "#8c8160";
  ctx.fillRect(0, 0, 128, 128);
  ctx.strokeStyle = "rgba(0,0,0,0.18)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 128; i += 4) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 128);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(128, i);
    ctx.stroke();
  }
  blotches(ctx, 128, 128, rand, 8, 10, 40, "40,35,20", 0.25);
  grain(ctx, 128, 128, rand, 30);
  return toTex(c, true);
}

export interface SignOpts {
  fg?: string;
  bg?: string | null;
  border?: string | null;
  font?: string;
  size?: number;
  spacing?: number;
  worn?: boolean;
  seed?: number;
}

export function makeSign(lines: string[], w: number, h: number, o: SignOpts = {}) {
  const rand = rng(o.seed ?? 77);
  const { c, ctx } = mk(w, h);
  const r = Math.min(w, h) * 0.09;
  if (o.bg) {
    ctx.fillStyle = o.bg;
    ctx.beginPath();
    ctx.roundRect(0, 0, w, h, r);
    ctx.fill();
  }
  if (o.border) {
    ctx.strokeStyle = o.border;
    ctx.lineWidth = Math.max(4, h * 0.05);
    ctx.beginPath();
    ctx.roundRect(h * 0.06, h * 0.06, w - h * 0.12, h - h * 0.12, r * 0.7);
    ctx.stroke();
  }
  const size = o.size ?? (h / (lines.length + 0.7)) * 0.78;
  ctx.fillStyle = o.fg ?? "#e6e6cc";
  ctx.font = `${size}px ${o.font ?? FONT_DISPLAY}`;
  ctx.textBaseline = "middle";
  ctx.textAlign = "center";
  const lh = size * 1.25;
  const y0 = h / 2 - ((lines.length - 1) * lh) / 2;
  lines.forEach((ln, i) => spaced(ctx, ln, w / 2, y0 + i * lh, o.spacing ?? size * 0.08, "center"));
  if (o.worn) {
    ctx.globalCompositeOperation = "destination-out";
    for (let i = 0; i < (w * h) / 500; i++) {
      ctx.fillStyle = `rgba(0,0,0,${0.2 + rand() * 0.6})`;
      ctx.fillRect(rand() * w, rand() * h, 1 + rand() * 4, 1 + rand() * 3);
    }
    ctx.globalCompositeOperation = "source-over";
  }
  return toTex(c, true);
}

export function makeBanner() {
  const W = 512;
  const H = 1280;
  const rand = rng(31);
  const { c, ctx } = mk(W, H);
  ctx.fillStyle = "#14181a";
  ctx.fillRect(0, 0, W, H);
  for (let x = 0; x < W; x += 64) {
    const g = ctx.createLinearGradient(x, 0, x + 64, 0);
    g.addColorStop(0, "rgba(255,255,255,0.06)");
    g.addColorStop(0.5, "rgba(0,0,0,0.25)");
    g.addColorStop(1, "rgba(255,255,255,0.04)");
    ctx.fillStyle = g;
    ctx.fillRect(x, 0, 64, H);
  }
  ctx.fillStyle = "#cdb85c";
  ctx.fillRect(0, 0, W, 54);
  ctx.fillStyle = "rgba(0,0,0,0.35)";
  ctx.fillRect(0, 54, W, 8);
  ctx.strokeStyle = "#cdb85c";
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.arc(256, 430, 200, 0, Math.PI * 2);
  ctx.stroke();
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(256, 430, 178, 0, Math.PI * 2);
  ctx.stroke();
  starPath(ctx, 256, 430, 150, 60);
  ctx.fillStyle = "#cdb85c";
  ctx.fill();
  ctx.textAlign = "center";
  ctx.font = `104px ${FONT_DISPLAY}`;
  spaced(ctx, "ЭКРОН", 256, 790, 6, "center");
  ctx.fillRect(70, 826, 372, 6);
  ctx.font = `bold 34px ${FONT_MONO}`;
  spaced(ctx, "КОМАНДНЫЙ ПУНКТ", 256, 884, 3, "center");
  for (let i = 0; i < 3; i++) ctx.fillRect(90, 960 + i * 34, 332, 14);
  // swallow-tail
  ctx.globalCompositeOperation = "destination-out";
  ctx.beginPath();
  ctx.moveTo(0, H);
  ctx.lineTo(256, H - 150);
  ctx.lineTo(W, H);
  ctx.closePath();
  ctx.fill();
  ctx.globalCompositeOperation = "source-over";
  blotches(ctx, W, H, rand, 20, 40, 160, "0,0,0", 0.3);
  grain(ctx, W, H, rand, 18);
  return toTex(c, true);
}

export function makeMap() {
  const W = 1024;
  const H = 640;
  const rand = rng(41);
  const { c, ctx } = mk(W, H);
  ctx.fillStyle = "#cbc59f";
  ctx.fillRect(0, 0, W, H);
  blotches(ctx, W, H, rand, 30, 60, 220, "120,100,60", 0.18);
  blotches(ctx, W, H, rand, 20, 60, 200, "240,235,200", 0.15);

  // contours
  const centers = [
    [300, 300, 1],
    [720, 360, 0.8],
  ];
  for (const [cx, cy, sc] of centers) {
    for (let k = 1; k < 10; k++) {
      const base = k * 24 * sc;
      const p1 = rand() * 6;
      const p2 = rand() * 6;
      ctx.beginPath();
      for (let a = 0; a <= 64; a++) {
        const t = (a / 64) * Math.PI * 2;
        const r = base * (1 + 0.16 * Math.sin(3 * t + p1) + 0.1 * Math.sin(5 * t + p2));
        const x = cx + Math.cos(t) * r * 1.3;
        const y = cy + Math.sin(t) * r;
        if (a === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.strokeStyle = k % 3 === 0 ? "rgba(110,86,40,0.75)" : "rgba(130,106,56,0.45)";
      ctx.lineWidth = k % 3 === 0 ? 2.4 : 1.4;
      ctx.stroke();
    }
  }
  // river
  ctx.strokeStyle = "rgba(70,110,140,0.85)";
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(0, 520);
  ctx.bezierCurveTo(260, 420, 480, 640, 1024, 470);
  ctx.stroke();
  // grid
  ctx.strokeStyle = "rgba(40,70,30,0.4)";
  ctx.lineWidth = 1.5;
  ctx.font = `bold 18px ${FONT_MONO}`;
  ctx.fillStyle = "rgba(40,70,30,0.8)";
  ctx.textAlign = "center";
  for (let i = 1; i < 8; i++) {
    ctx.beginPath();
    ctx.moveTo(i * 128, 0);
    ctx.lineTo(i * 128, H);
    ctx.stroke();
    ctx.fillText(String.fromCharCode(64 + i), i * 128 - 64, 22);
  }
  for (let j = 1; j < 5; j++) {
    ctx.beginPath();
    ctx.moveTo(0, j * 128);
    ctx.lineTo(W, j * 128);
    ctx.stroke();
    ctx.fillText(String(j), 16, j * 128 - 60);
  }
  // routes
  ctx.strokeStyle = "#b8281f";
  ctx.lineWidth = 6;
  ctx.setLineDash([22, 14]);
  ctx.beginPath();
  ctx.moveTo(120, 520);
  ctx.bezierCurveTo(260, 380, 420, 420, 560, 260);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = "#b8281f";
  ctx.beginPath();
  ctx.moveTo(560, 260);
  ctx.lineTo(520, 262);
  ctx.lineTo(548, 296);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "#1c3f78";
  ctx.lineWidth = 6;
  ctx.setLineDash([22, 14]);
  ctx.beginPath();
  ctx.moveTo(900, 110);
  ctx.bezierCurveTo(800, 200, 760, 170, 640, 250);
  ctx.stroke();
  ctx.setLineDash([]);
  for (const [x, y] of [
    [560, 250],
    [330, 330],
    [800, 420],
    [180, 160],
  ]) {
    ctx.fillStyle = "#b8281f";
    ctx.beginPath();
    ctx.arc(x, y, 14, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#f4e9c8";
    ctx.beginPath();
    ctx.arc(x, y, 5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = "rgba(30,40,20,0.9)";
  ctx.font = `34px ${FONT_DISPLAY}`;
  ctx.textAlign = "left";
  spaced(ctx, "ОП. «СТАЛЬНОЙ ЩИТ»", 28, H - 28, 3);
  grain(ctx, W, H, rand, 22);
  return toTex(c, true);
}

export function makeCabinet() {
  const rand = rng(61);
  const { c, ctx } = mk(256, 384);
  ctx.fillStyle = "#56624c";
  ctx.fillRect(0, 0, 256, 384);
  ctx.strokeStyle = "rgba(0,0,0,0.6)";
  ctx.lineWidth = 6;
  ctx.strokeRect(10, 10, 236, 364);
  ctx.strokeStyle = "rgba(255,255,255,0.1)";
  ctx.lineWidth = 2;
  ctx.strokeRect(16, 16, 224, 352);
  // warning triangle
  ctx.fillStyle = "#e0b81c";
  ctx.beginPath();
  ctx.moveTo(128, 46);
  ctx.lineTo(196, 164);
  ctx.lineTo(60, 164);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "#121208";
  ctx.lineWidth = 8;
  ctx.lineJoin = "round";
  ctx.stroke();
  ctx.fillStyle = "#121208";
  ctx.font = `bold 78px ${FONT_DISPLAY}`;
  ctx.textAlign = "center";
  ctx.fillText("!", 128, 146);
  ctx.fillStyle = "#e6e6cc";
  ctx.font = `34px ${FONT_DISPLAY}`;
  spaced(ctx, "ОПАСНО", 128, 214, 3, "center");
  ctx.font = `bold 26px ${FONT_MONO}`;
  spaced(ctx, "380 В", 128, 252, 3, "center");
  for (let i = 0; i < 6; i++) {
    ctx.fillStyle = "rgba(0,0,0,0.65)";
    ctx.fillRect(48, 290 + i * 12, 160, 5);
  }
  blotches(ctx, 256, 384, rand, 10, 20, 70, "6,8,4", 0.3);
  grain(ctx, 256, 384, rand, 24);
  return toTex(c, true);
}

export function makeGlow() {
  const { c, ctx } = mk(256, 256);
  const g = ctx.createRadialGradient(128, 128, 0, 128, 128, 128);
  g.addColorStop(0, "rgba(255,255,255,1)");
  g.addColorStop(0.25, "rgba(255,255,255,0.45)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 256);
  return toTex(c, true);
}
