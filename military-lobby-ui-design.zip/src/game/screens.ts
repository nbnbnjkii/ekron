import * as THREE from "three";
import { FONT_DISPLAY, FONT_MONO, spaced, starPath } from "./textures";

/** Logical monitor size (same 16:9 grid as the original 768×432 artwork). */
export const LW = 768;
export const LH = 432;
const PX = 1280;
const PY = 720;
const SC = PX / LW;

type Ctx = CanvasRenderingContext2D;

const COL = {
  accent: "#a7eac0",
  bright: "#e4fff0",
  dim: "#6f9c84",
  amber: "#ffc247",
  red: "#ff5a4d",
};

export interface LobbyState {
  page: 0 | 1;
  settings: "main" | "graphics" | "controls";
  controlMode: "player" | "car" | "drone";
  muted: boolean;
  canContinue: boolean;
  gameReady: boolean;
  loadProgress: number;
  notice: string;
  quality: 0 | 1 | 2;
  fps: 30 | 60;
  introPlaying: boolean;
}

export interface ScreenActions {
  resume(): void;
  newGame(): void;
  save(): void;
  setMuted(m: boolean): void;
  setGraphics(q: number | null, fps: number | null): void;
  feedback(kind: "click" | "ok" | "deny"): void;
}

interface Item {
  row: number;
  text: string;
  button: boolean;
  x0: number;
  x1: number;
  active?: boolean;
  disabled?: boolean;
  center?: boolean;
  tag?: string;
  kind?: "title" | "status" | "info" | "note";
  num?: string;
  action?: () => void;
}

const TITLES = ["ЭКРОН · КОМАНДНЫЙ ПУНКТ", "НАСТРОЙКИ / ИНФОРМАЦИЯ", "ИНТРО · касание: пауза", "ПОЛЕВОЕ РУКОВОДСТВО"];

const CONTROLS: Record<LobbyState["controlMode"], string[]> = {
  player: ["Управление: игрок", "WASD — ходьба · Shift — бег", "Мышь / сенсор — обзор", "Пробел — прыжок · C — присесть"],
  car: ["Управление: машина", "W / S — газ и тормоз", "A / D — руль · Пробел — ручник", "Shift — нитро · R — сброс"],
  drone: ["Управление: дрон", "WASD — полёт по горизонтали", "Пробел / C — вверх и вниз", "Q / E — поворот · F — камера"],
};

const BLIPS: [number, number][] = [
  [0.6, 0.5],
  [1.7, 0.8],
  [2.4, 0.35],
  [3.3, 0.65],
  [4.1, 0.9],
  [5.0, 0.45],
  [5.7, 0.75],
];

const pad = (n: number) => String(n).padStart(2, "0");
const fmt = (t: number) => `${pad(Math.floor(t / 60))}:${pad(Math.floor(t % 60))}`;

export class Screens {
  textures: THREE.CanvasTexture[] = [];
  state: LobbyState;
  introTime = 0;
  pendingPing = false;

  private ctxs: Ctx[] = [];
  private dirty = [true, true, true, true];
  private hover = { screen: -1, key: "" };
  private overlay: HTMLCanvasElement;
  private noticeAt = 0;
  private clock = 0;
  private lastSec = -1;
  private lastIntroDraw = -1;
  private lastSweepRev = -1;

  constructor(
    initial: Partial<LobbyState>,
    private actions: ScreenActions,
  ) {
    this.state = {
      page: 0,
      settings: "main",
      controlMode: "player",
      muted: false,
      canContinue: false,
      gameReady: false,
      loadProgress: 0,
      notice: "",
      quality: 1,
      fps: 60,
      introPlaying: true,
      ...initial,
    };
    for (let i = 0; i < 4; i++) {
      const c = document.createElement("canvas");
      c.width = PX;
      c.height = PY;
      this.ctxs.push(c.getContext("2d")!);
      const t = new THREE.CanvasTexture(c);
      t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = 8;
      this.textures.push(t);
    }
    this.overlay = this.makeOverlay();
  }

  private makeOverlay() {
    const c = document.createElement("canvas");
    c.width = PX;
    c.height = PY;
    const ctx = c.getContext("2d")!;
    ctx.setTransform(SC, 0, 0, SC, 0, 0);
    ctx.fillStyle = "rgba(0,0,0,0.2)";
    for (let y = 0; y < LH; y += 3) ctx.fillRect(0, y, LW, 1);
    const g = ctx.createRadialGradient(LW / 2, LH / 2, LH * 0.45, LW / 2, LH / 2, LW * 0.7);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(1, "rgba(0,0,0,0.5)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, LW, LH);
    return c;
  }

  /* ------------------------------------------------------------ state API */

  markAllDirty() {
    this.dirty = [true, true, true, true];
  }

  patch(p: Partial<LobbyState>) {
    Object.assign(this.state, p);
    this.markAllDirty();
  }

  /** map-loading simulation; returns true the moment loading completes */
  setLoad(p: number): boolean {
    const s = this.state;
    if (s.gameReady) return false;
    if (p >= 1) {
      s.loadProgress = 1;
      s.gameReady = true;
      this.dirty[0] = true;
      return true;
    }
    if (p - s.loadProgress >= 0.02) {
      s.loadProgress = p;
      this.dirty[0] = true;
    }
    return false;
  }

  notify(text: string) {
    this.state.notice = text;
    this.noticeAt = this.clock;
    this.dirty[0] = true;
  }

  /* ----------------------------------------------------------------- items */

  private items(i: number): Item[] {
    const s = this.state;
    const a = this.actions;
    const btn = (row: number, text: string, action: () => void, extra: Partial<Item> = {}): Item => ({
      row,
      text,
      button: true,
      x0: 12,
      x1: 756,
      action,
      ...extra,
    });
    const txt = (row: number, text: string, extra: Partial<Item> = {}): Item => ({
      row,
      text,
      button: false,
      x0: 12,
      x1: 756,
      ...extra,
    });
    const needReady = (fn: () => void) => () => {
      if (!s.gameReady) {
        this.notify("Карта готовится в фоне…");
        a.feedback("deny");
        return;
      }
      fn();
    };

    if (i === 0) {
      if (s.page === 0) {
        return [
          txt(0, "Добро пожаловать", { kind: "title", tag: s.canContinue ? "СЕССИЯ СОХРАНЕНА" : "НОВЫЙ ИГРОК" }),
          btn(
            1,
            s.canContinue ? "Продолжить игру" : "Начать игру",
            needReady(() => {
              if (s.canContinue) a.resume();
              else this.patch({ page: 1 });
            }),
            { tag: s.canContinue ? "▶" : "" },
          ),
          btn(
            2,
            "Новая игра",
            needReady(() => this.patch({ page: 1 })),
          ),
          s.canContinue
            ? btn(3, "Сохранить игру", needReady(() => a.save()))
            : btn(3, "Выберите режим игры", () => a.feedback("deny"), { disabled: true }),
          txt(4, !s.gameReady ? "Карта готовится в фоне…" : s.notice, { kind: "status" }),
        ];
      }
      return [
        txt(0, "Выберите режим игры", { kind: "title" }),
        btn(1, "Творческий · играть", needReady(() => a.newGame()), { tag: "РЕЖИМ 01" }),
        btn(2, "Выживание пока недоступно", () => a.feedback("deny"), { disabled: true, tag: "СКОРО" }),
        btn(3, "Назад", () => this.patch({ page: 0 })),
        txt(4, !s.gameReady ? "Карта готовится в фоне…" : s.notice, { kind: "status" }),
      ];
    }

    if (i === 1) {
      if (s.settings === "main") {
        return [
          btn(
            0,
            s.muted ? "Звук: выключен" : "Звук: включён",
            () => {
              a.setMuted(!s.muted);
            },
            { tag: s.muted ? "OFF" : "ON", active: !s.muted },
          ),
          btn(1, "Управление: игрок", () => this.patch({ settings: "controls", controlMode: "player" })),
          btn(2, "Управление: машина", () => this.patch({ settings: "controls", controlMode: "car" })),
          btn(3, "Управление: дрон", () => this.patch({ settings: "controls", controlMode: "drone" })),
          btn(4, "Настройки графики", () => this.patch({ settings: "graphics" })),
        ];
      }
      if (s.settings === "controls") {
        const lines = CONTROLS[s.controlMode];
        return [
          txt(0, lines[0], { kind: "title" }),
          txt(1, lines[1], { kind: "info", num: "01" }),
          txt(2, lines[2], { kind: "info", num: "02" }),
          txt(3, lines[3], { kind: "info", num: "03" }),
          btn(4, "Назад", () => this.patch({ settings: "main" })),
        ];
      }
      const names = ["Средние", "Высокие", "Ультра"];
      const fx = [
        "Тени: нет · Свечение: нет",
        "Тени: средние · Свечение: да",
        "Тени: высокие · Свечение: макс.",
      ];
      return [
        ...names.map((n, q) =>
          btn(0, n, () => a.setGraphics(q, null), {
            x0: q * 256 + 8,
            x1: (q + 1) * 256 - 8,
            center: true,
            active: s.quality === q,
          }),
        ),
        btn(1, "30 FPS", () => a.setGraphics(null, 30), { x0: 8, x1: 376, center: true, active: s.fps === 30 }),
        btn(1, "60 FPS", () => a.setGraphics(null, 60), { x0: 392, x1: 760, center: true, active: s.fps === 60 }),
        btn(2, "Назад", () => this.patch({ settings: "main" })),
        txt(3, "Разрешение рендера: 60 / 80 / 100%", { kind: "note" }),
        txt(4, fx[s.quality], { kind: "note" }),
      ];
    }

    if (i === 3) {
      return [
        txt(0, "Здесь нет оружия и строительства", { kind: "info", num: "01" }),
        txt(1, "Обзор и ходьба — как в игре", { kind: "info", num: "02" }),
        txt(2, "Кнопки находятся на стенах", { kind: "info", num: "03" }),
        txt(3, "Продолжить возвращает в сессию", { kind: "info", num: "04" }),
        txt(4, "Настройки — на правой стене", { kind: "info", num: "05" }),
      ];
    }
    return [];
  }

  private itemAt(i: number, u: number, v: number): Item | null {
    const x = u * LW;
    const y = v * LH;
    if (y > 400) return null;
    const row = Math.floor((y - 80) / 64);
    if (row < 0 || row > 4 || y - 80 - row * 64 > 58) return null;
    for (const it of this.items(i)) {
      if (it.button && it.row === row && x >= it.x0 && x <= it.x1) return it;
    }
    return null;
  }

  /** returns true when the pointer is over something clickable */
  setHover(screen: number, u: number, v: number): boolean {
    let key = "";
    let over = false;
    if (screen === 2) {
      over = true;
      key = "intro";
    } else if (screen >= 0) {
      const it = this.itemAt(screen, u, v);
      if (it && !it.disabled) {
        key = `${it.row}:${it.x0}`;
        over = true;
      }
    }
    if (this.hover.screen !== screen || this.hover.key !== key) {
      if (this.hover.screen >= 0) this.dirty[this.hover.screen] = true;
      this.hover = { screen, key };
      if (screen >= 0) this.dirty[screen] = true;
    }
    return over;
  }

  clearHover() {
    this.setHover(-1, 0, 0);
  }

  click(screen: number, u: number, v: number): boolean {
    if (screen === 2) {
      this.state.introPlaying = !this.state.introPlaying;
      this.dirty[2] = true;
      this.actions.feedback("click");
      return true;
    }
    const it = this.itemAt(screen, u, v);
    if (!it) return false;
    if (it.disabled) {
      this.actions.feedback("deny");
      return true;
    }
    this.actions.feedback("click");
    it.action?.();
    this.markAllDirty();
    return true;
  }

  /* ---------------------------------------------------------------- update */

  update(dt: number, visible: boolean[]) {
    this.clock += dt;
    const sec = Math.floor(this.clock);
    if (sec !== this.lastSec) {
      this.lastSec = sec;
      this.dirty[0] = this.dirty[1] = this.dirty[3] = true;
      if (this.state.notice && this.state.gameReady && this.clock - this.noticeAt > 5) {
        this.state.notice = "";
      }
    }
    for (const i of [0, 1, 3]) {
      if (this.dirty[i]) {
        this.draw(i);
        this.dirty[i] = false;
      }
    }
    // intro: continuous while playing & visible, capped at 30 fps
    const playing = this.state.introPlaying;
    if (playing && visible[2]) this.introTime += dt;
    const need = this.dirty[2] || (playing && visible[2] && this.clock - this.lastIntroDraw > 1 / 30);
    if (need) {
      this.draw(2);
      this.dirty[2] = false;
      this.lastIntroDraw = this.clock;
    }
  }

  /* --------------------------------------------------------------- drawing */

  private draw(i: number) {
    const ctx = this.ctxs[i];
    ctx.setTransform(SC, 0, 0, SC, 0, 0);
    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
    ctx.setLineDash([]);
    this.base(ctx, i);
    if (i === 2) this.introScreen(ctx);
    else for (const it of this.items(i)) this.drawItem(ctx, it, i);
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.drawImage(this.overlay, 0, 0);
    this.textures[i].needsUpdate = true;
  }

  private base(ctx: Ctx, i: number) {
    const g = ctx.createLinearGradient(0, 0, 0, LH);
    g.addColorStop(0, "#0a1a12");
    g.addColorStop(1, "#112a1d");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, LW, LH);

    ctx.strokeStyle = "rgba(120,220,160,0.05)";
    ctx.lineWidth = 1;
    for (let x = 0; x <= LW; x += 32) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, LH);
      ctx.stroke();
    }
    for (let y = 0; y <= LH; y += 32) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(LW, y);
      ctx.stroke();
    }
    if (i !== 2) {
      starPath(ctx, 640, 250, 170, 68);
      ctx.fillStyle = "rgba(167,234,192,0.04)";
      ctx.fill();
    }

    // header
    const hg = ctx.createLinearGradient(0, 0, LW, 0);
    hg.addColorStop(0, "rgba(34,86,58,0.95)");
    hg.addColorStop(1, "rgba(18,48,34,0.95)");
    ctx.fillStyle = hg;
    ctx.fillRect(0, 0, LW, 62);
    ctx.fillStyle = COL.accent;
    ctx.fillRect(0, 60, LW, 2);
    ctx.fillStyle = "rgba(0,0,0,0.35)";
    ctx.fillRect(14, 12, 40, 38);
    ctx.strokeStyle = COL.accent;
    ctx.lineWidth = 1.5;
    ctx.strokeRect(14, 12, 40, 38);
    ctx.fillStyle = COL.accent;
    ctx.font = `bold 22px ${FONT_MONO}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "alphabetic";
    ctx.fillText(pad(i + 1), 34, 39);
    ctx.textAlign = "left";
    ctx.font = `bold 27px ${FONT_MONO}`;
    ctx.fillStyle = COL.accent;
    ctx.fillText(TITLES[i], 68, 42);

    const blink = Math.floor(this.clock * 1.5) % 2 === 0;
    ctx.font = `bold 15px ${FONT_MONO}`;
    ctx.textAlign = "right";
    ctx.fillStyle = COL.dim;
    ctx.fillText("В СЕТИ", LW - 18, 24);
    ctx.fillStyle = blink ? "#5dff9a" : "#1f5a38";
    ctx.beginPath();
    ctx.arc(LW - 88, 19, 4.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = COL.dim;
    ctx.fillText(`КАНАЛ ${pad(i + 1)}/04`, LW - 18, 46);

    // footer
    if (i !== 2) {
      ctx.fillStyle = "rgba(0,0,0,0.38)";
      ctx.fillRect(0, 404, LW, 28);
      ctx.fillStyle = "rgba(167,234,192,0.35)";
      ctx.fillRect(0, 404, LW, 1);
      ctx.font = `bold 14px ${FONT_MONO}`;
      ctx.textAlign = "left";
      ctx.fillStyle = COL.dim;
      const foot = [
        "ЛОББИ · УЗЕЛ 01 · ГЛАВНОЕ МЕНЮ",
        "ЛОББИ · УЗЕЛ 02 · КОНФИГУРАЦИЯ",
        "",
        "WASD · ПРОБЕЛ · C · 1–4 · L — ЗАХВАТ МЫШИ",
      ][i];
      ctx.fillText(foot, 14, 423);
      const d = new Date();
      ctx.textAlign = "right";
      ctx.fillText(`${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`, LW - 14, 423);
    }

    // corner brackets
    ctx.strokeStyle = "rgba(167,234,192,0.55)";
    ctx.lineWidth = 2;
    const m = 5;
    const L = 16;
    for (const [x, y, sx, sy] of [
      [m, 66, 1, 1],
      [LW - m, 66, -1, 1],
      [m, LH - m, 1, -1],
      [LW - m, LH - m, -1, -1],
    ]) {
      ctx.beginPath();
      ctx.moveTo(x + sx * L, y);
      ctx.lineTo(x, y);
      ctx.lineTo(x, y + sy * L);
      ctx.stroke();
    }
    ctx.textAlign = "left";
  }

  private drawItem(ctx: Ctx, it: Item, screen: number) {
    const y = 80 + it.row * 64;
    const h = 58;
    const { x0, x1 } = it;
    const hov = this.hover.screen === screen && this.hover.key === `${it.row}:${it.x0}` && it.button && !it.disabled;
    ctx.textBaseline = "alphabetic";

    if (it.button) {
      const g = ctx.createLinearGradient(x0, 0, x1, 0);
      if (it.disabled) {
        g.addColorStop(0, "#13241b");
        g.addColorStop(1, "#0f1d16");
      } else if (hov) {
        g.addColorStop(0, "#2f6a49");
        g.addColorStop(1, "#3f8d64");
      } else if (it.active) {
        g.addColorStop(0, "#3b6c53");
        g.addColorStop(1, "#4a8264");
      } else {
        g.addColorStop(0, "#1e402e");
        g.addColorStop(1, "#2a4f3a");
      }
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.roundRect(x0, y, x1 - x0, h, 8);
      ctx.fill();
      ctx.lineWidth = hov ? 2.5 : 1.3;
      ctx.strokeStyle = hov ? "#d2ffe3" : it.active ? COL.accent : "rgba(167,234,192,0.28)";
      if (hov) {
        ctx.shadowColor = "rgba(120,255,180,0.9)";
        ctx.shadowBlur = 16;
      }
      ctx.stroke();
      ctx.shadowBlur = 0;
      if (!it.disabled) {
        ctx.fillStyle = hov || it.active ? COL.bright : "#6fcf97";
        ctx.beginPath();
        ctx.roundRect(x0 + 5, y + 11, 4, h - 22, 2);
        ctx.fill();
      }
      ctx.font = `bold 26px ${FONT_MONO}`;
      ctx.fillStyle = it.disabled ? "#58806a" : "#ffffff";
      if (it.center) {
        ctx.textAlign = "center";
        ctx.fillText(it.text, (x0 + x1) / 2, y + 38);
      } else {
        ctx.textAlign = "left";
        ctx.fillText(it.text, x0 + 24, y + 38);
        ctx.textAlign = "right";
        if (it.tag) {
          ctx.font = `bold 16px ${FONT_MONO}`;
          ctx.fillStyle = it.disabled ? "#58806a" : it.active ? COL.bright : COL.accent;
          ctx.fillText(it.tag, x1 - 20, y + 36);
        } else if (!it.disabled) {
          ctx.font = `bold 30px ${FONT_MONO}`;
          ctx.fillStyle = hov ? COL.bright : "rgba(167,234,192,0.55)";
          ctx.fillText("›", x1 - 22, y + 38);
        }
      }
      ctx.textAlign = "left";
      return;
    }

    // non-button rows
    if (it.kind === "title") {
      ctx.font = `bold 31px ${FONT_MONO}`;
      ctx.fillStyle = COL.bright;
      ctx.textAlign = "left";
      ctx.fillText(it.text, x0 + 6, y + 38);
      ctx.fillStyle = "rgba(167,234,192,0.45)";
      ctx.fillRect(x0 + 6, y + 48, 120, 3);
      if (it.tag) {
        ctx.font = `bold 15px ${FONT_MONO}`;
        ctx.textAlign = "right";
        ctx.fillStyle = COL.dim;
        ctx.fillText(it.tag, x1 - 8, y + 36);
        ctx.textAlign = "left";
      }
    } else if (it.kind === "status") {
      const wait = !this.state.gameReady;
      ctx.fillStyle = wait ? COL.amber : it.text ? "#5dff9a" : "rgba(0,0,0,0)";
      ctx.beginPath();
      ctx.arc(x0 + 12, y + 29, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.font = `bold 22px ${FONT_MONO}`;
      ctx.fillStyle = wait ? COL.amber : COL.accent;
      ctx.textAlign = "left";
      ctx.fillText(it.text, x0 + 30, y + 37);
      if (wait) {
        const bx = 520;
        const bw = 220;
        ctx.fillStyle = "rgba(0,0,0,0.5)";
        ctx.fillRect(bx, y + 22, bw, 14);
        ctx.fillStyle = COL.amber;
        ctx.fillRect(bx + 2, y + 24, (bw - 4) * this.state.loadProgress, 10);
        ctx.font = `bold 14px ${FONT_MONO}`;
        ctx.textAlign = "right";
        ctx.fillText(`${Math.round(this.state.loadProgress * 100)}%`, bx - 8, y + 36);
        ctx.textAlign = "left";
      }
    } else if (it.kind === "info") {
      ctx.fillStyle = "rgba(10,28,19,0.75)";
      ctx.beginPath();
      ctx.roundRect(x0, y, x1 - x0, h, 8);
      ctx.fill();
      ctx.strokeStyle = "rgba(167,234,192,0.18)";
      ctx.lineWidth = 1.2;
      ctx.stroke();
      ctx.fillStyle = "rgba(167,234,192,0.14)";
      ctx.beginPath();
      ctx.roundRect(x0 + 8, y + 9, 54, h - 18, 6);
      ctx.fill();
      ctx.font = `bold 22px ${FONT_MONO}`;
      ctx.fillStyle = COL.accent;
      ctx.textAlign = "center";
      ctx.fillText(it.num ?? "", x0 + 35, y + 37);
      ctx.textAlign = "left";
      ctx.font = `bold 25px ${FONT_MONO}`;
      ctx.fillStyle = "#f2fff7";
      ctx.fillText(it.text, x0 + 80, y + 38);
    } else {
      ctx.font = `bold 20px ${FONT_MONO}`;
      ctx.fillStyle = COL.dim;
      ctx.textAlign = "left";
      ctx.fillText(it.text, x0 + 10, y + 36);
    }
  }

  /* ----------------------------------------------------------------- intro */

  private introScreen(ctx: Ctx) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 64, LW, 340);
    ctx.clip();
    ctx.translate(0, 64);
    this.introFrame(ctx, this.introTime, !this.state.introPlaying);
    ctx.restore();

    // caption bar
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillRect(0, 404, LW, 28);
    const loop = (this.introTime % 24) / 24;
    ctx.fillStyle = "rgba(167,234,192,0.25)";
    ctx.fillRect(0, 404, LW, 3);
    ctx.fillStyle = COL.accent;
    ctx.fillRect(0, 404, LW * loop, 3);
    ctx.font = `bold 15px ${FONT_MONO}`;
    ctx.textAlign = "left";
    ctx.fillStyle = COL.accent;
    const hov = this.hover.screen === 2;
    ctx.fillText(
      this.state.introPlaying ? "Коснитесь экрана: пауза / продолжить" : "Пауза · коснитесь экрана, чтобы продолжить",
      14,
      424,
    );
    ctx.textAlign = "right";
    ctx.fillStyle = hov ? COL.bright : COL.dim;
    ctx.fillText(`${fmt(this.introTime % 24)} / 00:24`, LW - 14, 424);
    ctx.textAlign = "left";
  }

  private introFrame(ctx: Ctx, t: number, paused: boolean) {
    const W = LW;
    const H = 340;
    ctx.fillStyle = "#040c08";
    ctx.fillRect(0, 0, W, H);

    const T = t % 24;
    const scene = Math.floor(T / 8);
    const lt = T - scene * 8;
    const env = Math.max(0, Math.min(1, lt / 0.7, (8 - lt) / 0.7));
    ctx.save();
    ctx.globalAlpha = env;
    if (scene === 0) this.sceneRadar(ctx, lt, W, H);
    else if (scene === 1) this.sceneEmblem(ctx, lt, t, W, H);
    else this.sceneMap(ctx, lt, W, H);
    ctx.restore();
    if (scene !== 0) this.lastSweepRev = -1;

    // HUD overlay
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.fillRect(0, 0, W, 26);
    const blink = Math.floor(t * 1.6) % 2 === 0 || paused;
    ctx.fillStyle = blink ? COL.red : "#5a1c18";
    ctx.beginPath();
    ctx.arc(20, 13, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.font = `bold 14px ${FONT_MONO}`;
    ctx.fillStyle = COL.accent;
    ctx.textAlign = "left";
    ctx.fillText("REC · ЭКРОН // ПЕРЕХВАТ КАНАЛА", 34, 18);
    ctx.textAlign = "right";
    ctx.fillText(`TC 00:${fmt(T)}:${pad(Math.floor((T % 1) * 25))}`, W - 14, 18);
    ctx.textAlign = "left";

    if (paused) {
      ctx.fillStyle = "rgba(2,10,6,0.62)";
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = "rgba(10,30,20,0.9)";
      ctx.beginPath();
      ctx.roundRect(W / 2 - 150, H / 2 - 58, 300, 116, 14);
      ctx.fill();
      ctx.strokeStyle = COL.accent;
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = COL.bright;
      ctx.fillRect(W / 2 - 100, H / 2 - 28, 14, 46);
      ctx.fillRect(W / 2 - 76, H / 2 - 28, 14, 46);
      ctx.font = `32px ${FONT_DISPLAY}`;
      ctx.textAlign = "left";
      spaced(ctx, "ПАУЗА", W / 2 - 40, H / 2 + 8, 4);
      ctx.font = `bold 14px ${FONT_MONO}`;
      ctx.fillStyle = COL.dim;
      ctx.textAlign = "center";
      ctx.fillText("касание — продолжить", W / 2 + 10, H / 2 + 40);
      ctx.textAlign = "left";
    }
  }

  private sceneRadar(ctx: Ctx, lt: number, W: number, H: number) {
    const cx = 230;
    const cy = 176;
    const R = 134;
    ctx.strokeStyle = "rgba(111,207,151,0.08)";
    ctx.lineWidth = 1;
    for (let x = 0; x < W; x += 24) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, H);
      ctx.stroke();
    }
    for (let y = 0; y < H; y += 24) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(W, y);
      ctx.stroke();
    }
    ctx.strokeStyle = "rgba(167,234,192,0.38)";
    ctx.lineWidth = 1.3;
    for (let k = 1; k <= 4; k++) {
      ctx.beginPath();
      ctx.arc(cx, cy, (R * k) / 4, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.strokeStyle = "rgba(167,234,192,0.2)";
    for (let k = 0; k < 4; k++) {
      const a = (k * Math.PI) / 4;
      ctx.beginPath();
      ctx.moveTo(cx - Math.cos(a) * R, cy - Math.sin(a) * R);
      ctx.lineTo(cx + Math.cos(a) * R, cy + Math.sin(a) * R);
      ctx.stroke();
    }
    for (let d = 0; d < 360; d += 10) {
      const a = (d * Math.PI) / 180;
      const l = d % 30 === 0 ? 10 : 5;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * R, cy + Math.sin(a) * R);
      ctx.lineTo(cx + Math.cos(a) * (R + l), cy + Math.sin(a) * (R + l));
      ctx.stroke();
    }
    const sweep = lt * 1.25;
    const rev = Math.floor(sweep / (Math.PI * 2));
    if (rev !== this.lastSweepRev) {
      this.lastSweepRev = rev;
      this.pendingPing = true;
    }
    const a = sweep - Math.PI / 2;
    for (let i = 0; i < 44; i++) {
      ctx.fillStyle = `rgba(90,255,160,${0.3 * (1 - i / 44)})`;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, R, a - (i + 1) * 0.025, a - i * 0.025);
      ctx.closePath();
      ctx.fill();
    }
    ctx.strokeStyle = "#b8ffd2";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + Math.cos(a) * R, cy + Math.sin(a) * R);
    ctx.stroke();
    for (const [ang, rad] of BLIPS) {
      const ba = ang - Math.PI / 2;
      const diff = (((a - ba) % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
      const br = Math.max(0, 1 - diff / 4.2);
      if (br <= 0) continue;
      const bx = cx + Math.cos(ba) * rad * R;
      const by = cy + Math.sin(ba) * rad * R;
      ctx.fillStyle = `rgba(255,214,120,${br})`;
      ctx.beginPath();
      ctx.arc(bx, by, 3.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = `rgba(255,214,120,${br * 0.6})`;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(bx, by, 4 + (1 - br) * 12, 0, Math.PI * 2);
      ctx.stroke();
    }
    const lines = [
      "СКАНИРОВАНИЕ СЕКТОРА 07",
      "ЦЕЛЕЙ ОБНАРУЖЕНО: 07",
      "ДАЛЬНОСТЬ: 12.4 КМ",
      "ПОМЕХИ: НИЗКИЕ",
      "КАНАЛ СВЯЗИ: ЗАЩИЩЁН",
    ];
    ctx.font = `bold 18px ${FONT_MONO}`;
    ctx.fillStyle = COL.accent;
    ctx.textAlign = "left";
    lines.forEach((ln, i) => {
      const n = Math.max(0, Math.floor((lt - 0.5 - i * 0.55) * 28));
      ctx.fillText(ln.slice(0, n), 420, 92 + i * 28);
    });
    const ta = Math.max(0, Math.min(1, (lt - 3) / 1.2));
    ctx.save();
    ctx.globalAlpha *= ta;
    ctx.fillStyle = COL.bright;
    ctx.font = `64px ${FONT_DISPLAY}`;
    spaced(ctx, "ЭКРОН", 420, 282, 8);
    ctx.fillStyle = COL.accent;
    ctx.fillRect(420, 296, 230 * ta, 4);
    ctx.restore();
  }

  private sceneEmblem(ctx: Ctx, lt: number, t: number, W: number, H: number) {
    const cx = W / 2;
    const cy = 170;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.lineWidth = 3;
    ctx.strokeStyle = "rgba(167,234,192,0.6)";
    ctx.setLineDash([16, 10]);
    ctx.save();
    ctx.rotate(t * 0.45);
    ctx.beginPath();
    ctx.arc(0, 0, 122, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
    ctx.setLineDash([6, 8]);
    ctx.strokeStyle = "rgba(255,194,71,0.6)";
    ctx.save();
    ctx.rotate(-t * 0.7);
    ctx.beginPath();
    ctx.arc(0, 0, 100, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
    ctx.setLineDash([]);
    ctx.strokeStyle = COL.accent;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 82, 0, Math.PI * 2);
    ctx.stroke();
    const pulse = 1 + Math.sin(t * 2.4) * 0.04;
    ctx.save();
    ctx.rotate(Math.sin(t * 0.6) * 0.12);
    ctx.scale(pulse, pulse);
    starPath(ctx, 0, 0, 70, 28);
    ctx.fillStyle = "#cdb85c";
    ctx.shadowColor = "rgba(255,220,120,0.8)";
    ctx.shadowBlur = 18;
    ctx.fill();
    ctx.restore();
    ctx.restore();

    ctx.font = `bold 15px ${FONT_MONO}`;
    ctx.textAlign = "left";
    for (let i = 0; i < 11; i++) {
      const v = (((i + 3) * 7919 + Math.floor(t * 9) * 131) % 65536).toString(16).toUpperCase().padStart(4, "0");
      ctx.fillStyle = `rgba(167,234,192,${0.25 + 0.3 * ((i + Math.floor(t * 3)) % 3 === 0 ? 1 : 0)})`;
      ctx.fillText(`0x${v}`, 28, 60 + i * 24);
      const bw = 40 + Math.abs(Math.sin(t * 1.3 + i * 1.7)) * 70;
      ctx.fillStyle = "rgba(167,234,192,0.35)";
      ctx.fillRect(W - 28 - bw, 48 + i * 24, bw, 10);
    }
    ctx.fillStyle = COL.bright;
    ctx.font = `46px ${FONT_DISPLAY}`;
    spaced(ctx, "ЭКРОН", cx, 54, 10, "center");
    ctx.font = `bold 24px ${FONT_MONO}`;
    ctx.fillStyle = COL.accent;
    const ta = Math.max(0, Math.min(1, (lt - 0.8) / 1));
    ctx.save();
    ctx.globalAlpha *= ta;
    spaced(ctx, "КОМАНДНЫЙ ПУНКТ", cx, 308, 5, "center");
    ctx.restore();

    // ticker
    ctx.fillStyle = "rgba(0,0,0,0.4)";
    ctx.fillRect(0, H - 24, W, 24);
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, H - 24, W, 24);
    ctx.clip();
    ctx.font = `bold 14px ${FONT_MONO}`;
    ctx.fillStyle = COL.amber;
    const msg = "СВЯЗЬ УСТАНОВЛЕНА  •  КАНАЛ 7 ЗАЩИЩЁН  •  СИНХРОНИЗАЦИЯ ДАННЫХ  •  КАРТА ЗАГРУЖЕНА  •  ";
    const mw = ctx.measureText(msg).width;
    const off = (t * 70) % mw;
    for (let k = -1; k < 3; k++) ctx.fillText(msg, k * mw - off, H - 8);
    ctx.restore();
  }

  private sceneMap(ctx: Ctx, lt: number, W: number, H: number) {
    ctx.strokeStyle = "rgba(111,207,151,0.1)";
    ctx.lineWidth = 1;
    for (let x = 0; x <= W; x += 48) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, H);
      ctx.stroke();
    }
    for (let y = 0; y <= H; y += 48) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(W, y);
      ctx.stroke();
    }
    // contours
    for (let k = 1; k < 10; k++) {
      ctx.beginPath();
      for (let s = 0; s <= 60; s++) {
        const a = (s / 60) * Math.PI * 2;
        const r = k * 17 * (1 + 0.15 * Math.sin(3 * a + 1) + 0.09 * Math.sin(5 * a + 2));
        const x = 300 + Math.cos(a) * r * 1.5;
        const y = 180 + Math.sin(a) * r;
        if (s === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.strokeStyle = k % 3 === 0 ? "rgba(90,200,140,0.55)" : "rgba(90,200,140,0.25)";
      ctx.stroke();
    }
    // units
    const units = [
      { n: "АЛЬФА", c: "#5dff9a", ax: 150, ay: 70, ph: 0 },
      { n: "БРАВО", c: "#5dc8ff", ax: 190, ay: 80, ph: 2 },
      { n: "ЧАРЛИ", c: "#ffc247", ax: 120, ay: 90, ph: 4 },
    ];
    units.forEach((u, idx) => {
      for (let k = 14; k >= 0; k--) {
        const tt = lt * 0.7 - k * 0.07 + u.ph;
        const x = 330 + Math.cos(tt) * u.ax;
        const y = 180 + Math.sin(tt * 1.6) * u.ay;
        ctx.fillStyle = u.c;
        ctx.globalAlpha = (1 - k / 15) * 0.7;
        ctx.beginPath();
        ctx.arc(x, y, k === 0 ? 5.5 : 2.2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      const hx = 330 + Math.cos(lt * 0.7 + u.ph) * u.ax;
      const hy = 180 + Math.sin(lt * 1.6 * 0.7 + u.ph * 1.6) * u.ay;
      ctx.font = `bold 13px ${FONT_MONO}`;
      ctx.fillStyle = u.c;
      ctx.textAlign = "left";
      ctx.fillText(`${u.n}-${idx + 1}`, hx + 9, hy - 7);
      // roster
      ctx.fillText(`● ${u.n}`, 590, 92 + idx * 26);
      ctx.fillStyle = COL.dim;
      ctx.fillText(["В ДВИЖЕНИИ", "НАБЛЮДЕНИЕ", "РАЗВЕДКА"][idx], 668, 92 + idx * 26);
    });
    // reticle
    const rx = 540;
    const ry = 150;
    const p = 1 + Math.sin(lt * 4) * 0.12;
    ctx.save();
    ctx.translate(rx, ry);
    ctx.rotate(lt * 0.8);
    ctx.strokeStyle = COL.red;
    ctx.lineWidth = 2;
    ctx.strokeRect(-20 * p, -20 * p, 40 * p, 40 * p);
    ctx.restore();
    ctx.strokeStyle = COL.red;
    ctx.beginPath();
    ctx.moveTo(rx - 34, ry);
    ctx.lineTo(rx - 10, ry);
    ctx.moveTo(rx + 10, ry);
    ctx.lineTo(rx + 34, ry);
    ctx.moveTo(rx, ry - 34);
    ctx.lineTo(rx, ry - 10);
    ctx.moveTo(rx, ry + 10);
    ctx.lineTo(rx, ry + 34);
    ctx.stroke();
    ctx.font = `bold 13px ${FONT_MONO}`;
    ctx.fillStyle = COL.red;
    ctx.fillText("ЦЕЛЬ · ТЧК-07", rx + 26, ry - 24);
    // title + progress
    ctx.fillStyle = COL.bright;
    ctx.font = `30px ${FONT_DISPLAY}`;
    spaced(ctx, "ОПЕРАЦИЯ «СТАЛЬНОЙ ЩИТ»", 28, 62, 3);
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.fillRect(28, H - 40, 320, 12);
    ctx.fillStyle = COL.accent;
    ctx.fillRect(30, H - 38, 316 * (lt / 8), 8);
    ctx.font = `bold 13px ${FONT_MONO}`;
    ctx.fillStyle = COL.dim;
    ctx.fillText(`РАЗВЁРТЫВАНИЕ ${Math.floor((lt / 8) * 100)}%`, 360, H - 30);
  }
}
