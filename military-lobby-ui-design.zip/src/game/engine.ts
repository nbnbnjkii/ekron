import * as THREE from "three";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";
import { buildWorld, viewSpot, type World } from "./scene";
import { Screens } from "./screens";
import { Player, type PlayerEvents } from "./player";
import { LobbyAudio } from "./audio";
import { FONT_DISPLAY, FONT_MONO } from "./textures";

export interface EngineCallbacks {
  onResume(): void;
  onNewGame(): void;
  onHover(over: boolean): void;
  onLockChange(locked: boolean): void;
  onToast(text: string): void;
}

const LS = {
  canContinue: "ekron.canContinue",
  muted: "ekron.muted",
  quality: "ekron.quality",
  fps: "ekron.fps",
};

function lsGet(k: string): string | null {
  try {
    return localStorage.getItem(k);
  } catch {
    return null;
  }
}
function lsSet(k: string, v: string) {
  try {
    localStorage.setItem(k, v);
  } catch {
    /* storage unavailable (private mode / sandbox) */
  }
}

const wrapAngle = (a: number) => Math.atan2(Math.sin(a), Math.cos(a));
const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

interface PointerInfo {
  x: number;
  y: number;
  sx: number;
  sy: number;
  st: number;
  moved: boolean;
  type: string;
}

export class LobbyEngine {
  readonly audio = new LobbyAudio();
  readonly isTouch: boolean;

  private renderer!: THREE.WebGLRenderer;
  private composer: EffectComposer | null = null;
  private bloom: UnrealBloomPass | null = null;
  private camera!: THREE.PerspectiveCamera;
  private world!: World;
  private screens!: Screens;
  private player = new Player();
  private canvas!: HTMLCanvasElement;
  private resizeObs: ResizeObserver | null = null;

  private raf = 0;
  private disposed = false;
  private paused = false;
  private idle = true;
  private time = 0;
  private lastFrame = 0;
  private lastRender = 0;
  private loadP = 0;

  private quality: 0 | 1 | 2 = 1;
  private fps: 30 | 60 = 60;

  private keys = new Set<string>();
  private stick = { x: 0, y: 0 };
  private crouchToggle = false;
  private pointers = new Map<number, PointerInfo>();
  private pointerNdc: THREE.Vector2 | null = null;
  private locked = false;
  private lastOver = false;
  private focusAnim: {
    t: number;
    fx: number;
    fz: number;
    fyaw: number;
    fpitch: number;
    tx: number;
    tz: number;
    tyaw: number;
    tpitch: number;
  } | null = null;

  private raycaster = new THREE.Raycaster();
  private frustum = new THREE.Frustum();
  private projMat = new THREE.Matrix4();
  private visible = [false, false, false, false];
  private cleanups: (() => void)[] = [];

  private ev: PlayerEvents = {
    step: () => this.audio.step(),
    jump: () => this.audio.jump(),
    land: () => this.audio.land(),
  };

  constructor(
    private container: HTMLElement,
    private cb: EngineCallbacks,
  ) {
    this.isTouch =
      typeof window !== "undefined" &&
      (window.matchMedia?.("(pointer: coarse)").matches || "ontouchstart" in window || navigator.maxTouchPoints > 0);
  }

  static async create(container: HTMLElement, cb: EngineCallbacks) {
    const e = new LobbyEngine(container, cb);
    await e.init();
    return e;
  }

  /* -------------------------------------------------------------------- init */

  private async init() {
    // make sure canvas/procedural text can use the webfonts
    try {
      const fonts = document.fonts;
      if (fonts) {
        const load = Promise.all([
          fonts.load(`700 26px ${FONT_MONO}`, "АБВабв"),
          fonts.load(`400 40px ${FONT_DISPLAY}`, "АБВабв"),
        ]);
        await Promise.race([load, new Promise((r) => setTimeout(r, 2200))]);
      }
    } catch {
      /* fonts are optional */
    }
    if (this.disposed) return;

    const muted = lsGet(LS.muted) === "1";
    const qRaw = Number(lsGet(LS.quality));
    this.quality = (lsGet(LS.quality) !== null && qRaw >= 0 && qRaw <= 2 ? qRaw : this.isTouch ? 0 : 1) as 0 | 1 | 2;
    this.fps = lsGet(LS.fps) === "30" ? 30 : 60;
    this.audio.muted = muted;

    this.screens = new Screens(
      {
        muted,
        canContinue: lsGet(LS.canContinue) === "1",
        quality: this.quality,
        fps: this.fps,
      },
      {
        resume: () => this.cb.onResume(),
        newGame: () => this.cb.onNewGame(),
        save: () => this.saveGame(),
        setMuted: (m) => this.applyMuted(m),
        setGraphics: (q, f) => {
          if (q !== null) this.applyQuality(q as 0 | 1 | 2);
          if (f !== null) this.applyFps(f as 30 | 60);
        },
        feedback: (k) => (k === "click" ? this.audio.click() : k === "ok" ? this.audio.ok() : this.audio.deny()),
      },
    );

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    const r = this.renderer;
    r.toneMapping = THREE.NeutralToneMapping;
    r.toneMappingExposure = 1.0;
    r.shadowMap.enabled = true;
    r.shadowMap.type = THREE.PCFSoftShadowMap;
    this.canvas = r.domElement;
    Object.assign(this.canvas.style, { display: "block", width: "100%", height: "100%", touchAction: "none", cursor: "grab", outline: "none" });
    this.canvas.tabIndex = 0;
    this.container.appendChild(this.canvas);

    this.camera = new THREE.PerspectiveCamera(72, 1, 0.08, 60);
    this.camera.rotation.order = "YXZ";

    this.world = buildWorld(this.screens.textures);
    this.world.scene.updateMatrixWorld(true);

    // post-processing (bloom) for High / Ultra
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    const target = new THREE.WebGLRenderTarget(w, h, { type: THREE.HalfFloatType, samples: 4 });
    this.composer = new EffectComposer(r, target);
    this.composer.addPass(new RenderPass(this.world.scene, this.camera));
    this.bloom = new UnrealBloomPass(new THREE.Vector2(w, h), 0.45, 0.55, 0.85);
    this.composer.addPass(this.bloom);
    this.composer.addPass(new OutputPass());

    this.applyQuality(this.quality, false);
    this.resize();
    this.player.reset(0, -3, 0);

    this.bindEvents();
    this.resizeObs = new ResizeObserver(() => this.resize());
    this.resizeObs.observe(this.container);

    // fonts that arrive late → redraw
    document.fonts?.ready.then(() => this.screens?.markAllDirty()).catch(() => undefined);

    this.lastFrame = performance.now();
    this.raf = requestAnimationFrame(this.frame);
  }

  /* ---------------------------------------------------------------- settings */

  private applyMuted(m: boolean) {
    this.audio.setMuted(m);
    this.screens.patch({ muted: m });
    lsSet(LS.muted, m ? "1" : "0");
  }

  toggleMute() {
    this.audio.init();
    this.applyMuted(!this.audio.muted);
    this.audio.click();
  }

  private applyQuality(q: 0 | 1 | 2, persist = true) {
    this.quality = q;
    this.world.setShadows(q);
    if (this.bloom) {
      this.bloom.strength = q === 2 ? 0.62 : 0.45;
      this.bloom.radius = q === 2 ? 0.7 : 0.5;
      this.bloom.threshold = q === 2 ? 0.8 : 0.85;
    }
    if (persist) lsSet(LS.quality, String(q));
    this.screens.patch({ quality: q });
    this.resize();
  }

  private applyFps(f: 30 | 60) {
    this.fps = f;
    lsSet(LS.fps, String(f));
    this.screens.patch({ fps: f });
  }

  private saveGame() {
    const d = new Date();
    const p = (n: number) => String(n).padStart(2, "0");
    lsSet("ekron.savedAt", String(Date.now()));
    this.screens.notify(`Игра сохранена · ${p(d.getHours())}:${p(d.getMinutes())}`);
    this.audio.ok();
  }

  /* --------------------------------------------------------------- public API */

  start() {
    this.audio.init();
    this.idle = false;
    // glide from the cinematic splash camera to the main command monitor
    const p = this.player;
    const s = viewSpot(0);
    this.focusAnim = {
      t: 0,
      fx: p.x,
      fz: p.z,
      fyaw: p.yaw,
      fpitch: p.pitch,
      tx: s.x,
      tz: s.z,
      tyaw: 0,
      tpitch: s.pitch,
    };
  }

  setPaused(p: boolean) {
    this.paused = p;
    if (p) {
      this.exitLock();
      this.keys.clear();
      this.stick = { x: 0, y: 0 };
      this.pointers.clear();
      this.audio.setAmbientLevel(0.12);
    } else {
      this.audio.setAmbientLevel(0.55);
      this.lastFrame = performance.now();
      this.screens.markAllDirty();
    }
  }

  /** the game session was started / continued: unlock "Продолжить" and "Сохранить" */
  sessionStarted() {
    lsSet(LS.canContinue, "1");
    this.screens.patch({ canContinue: true, page: 0 });
    this.audio.deploy();
  }

  returnedToLobby() {
    this.screens.patch({ page: 0 });
    this.screens.notify("Вы вернулись в лобби");
  }

  setStick(x: number, y: number) {
    this.stick.x = x;
    this.stick.y = y;
    if (x !== 0 || y !== 0) this.focusAnim = null;
  }

  touchJump() {
    if (this.idle || this.paused) return;
    this.player.jump(this.ev);
  }

  toggleCrouch(): boolean {
    this.crouchToggle = !this.crouchToggle;
    return this.crouchToggle;
  }

  focusScreen(i: number) {
    if (this.idle || this.paused) return;
    const s = viewSpot(i);
    const p = this.player;
    this.focusAnim = {
      t: 0,
      fx: p.x,
      fz: p.z,
      fyaw: p.yaw,
      fpitch: p.pitch,
      tx: s.x,
      tz: s.z,
      tyaw: p.yaw + wrapAngle(s.yaw - p.yaw),
      tpitch: s.pitch,
    };
    p.vx = 0;
    p.vz = 0;
    this.audio.click();
  }

  toggleLock() {
    if (this.locked) this.exitLock();
    else this.requestLock();
  }

  private requestLock() {
    if (!this.canvas || this.isTouch) return;
    try {
      const res = this.canvas.requestPointerLock() as unknown as Promise<void> | undefined;
      if (res && typeof res.catch === "function") {
        res.catch(() => this.cb.onToast("Захват мыши недоступен в этом окне — используйте перетаскивание"));
      }
    } catch {
      this.cb.onToast("Захват мыши недоступен в этом окне — используйте перетаскивание");
    }
  }

  private exitLock() {
    if (document.pointerLockElement === this.canvas) document.exitPointerLock();
  }

  /* ------------------------------------------------------------------ events */

  private bindEvents() {
    const on = <K extends keyof WindowEventMap>(t: Window, type: K, fn: (e: WindowEventMap[K]) => void) => {
      t.addEventListener(type, fn as EventListener);
      this.cleanups.push(() => t.removeEventListener(type, fn as EventListener));
    };
    const c = this.canvas;
    const onC = (type: string, fn: (e: PointerEvent) => void) => {
      c.addEventListener(type, fn as EventListener);
      this.cleanups.push(() => c.removeEventListener(type, fn as EventListener));
    };

    on(window, "keydown", (e) => this.onKey(e, true));
    on(window, "keyup", (e) => this.onKey(e, false));
    on(window, "blur", () => this.keys.clear());

    onC("pointerdown", (e) => this.onPointerDown(e));
    onC("pointermove", (e) => this.onPointerMove(e));
    onC("pointerup", (e) => this.onPointerUp(e));
    onC("pointercancel", (e) => {
      this.pointers.delete(e.pointerId);
    });
    onC("pointerleave", (e) => {
      if (e.pointerType !== "touch" && !this.locked) this.pointerNdc = null;
    });
    const ctxMenu = (e: Event) => e.preventDefault();
    c.addEventListener("contextmenu", ctxMenu);
    this.cleanups.push(() => c.removeEventListener("contextmenu", ctxMenu));

    const lockChange = () => {
      this.locked = document.pointerLockElement === this.canvas;
      if (this.locked) this.pointers.clear();
      this.cb.onLockChange(this.locked);
    };
    document.addEventListener("pointerlockchange", lockChange);
    this.cleanups.push(() => document.removeEventListener("pointerlockchange", lockChange));
  }

  private onKey(e: KeyboardEvent, down: boolean) {
    if (this.paused || this.idle) return;
    const code = e.code;
    const handled = [
      "KeyW", "KeyA", "KeyS", "KeyD", "Space", "KeyC", "ShiftLeft", "ShiftRight",
      "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "ControlLeft",
    ];
    if (handled.includes(code)) e.preventDefault();
    if (down) {
      if (e.repeat) return;
      this.keys.add(code);
      if (code === "Space") this.player.jump(this.ev);
      else if (code === "KeyL") this.toggleLock();
      else if (code === "KeyM") this.toggleMute();
      else if (code === "KeyE" || code === "Enter") this.tapNdc(0, 0);
      else if (code >= "Digit1" && code <= "Digit4") this.focusScreen(Number(code.slice(5)) - 1);
      if (["KeyW", "KeyA", "KeyS", "KeyD"].includes(code)) this.focusAnim = null;
    } else {
      this.keys.delete(code);
    }
  }

  private onPointerDown(e: PointerEvent) {
    if (this.paused || this.idle) return;
    this.audio.init();
    this.canvas.focus({ preventScroll: true });
    if (this.locked) {
      if (e.button === 0) this.tapNdc(0, 0);
      return;
    }
    try {
      this.canvas.setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
    this.pointers.set(e.pointerId, {
      x: e.clientX,
      y: e.clientY,
      sx: e.clientX,
      sy: e.clientY,
      st: performance.now(),
      moved: false,
      type: e.pointerType,
    });
    if (e.pointerType !== "touch") this.updateNdc(e);
  }

  private onPointerMove(e: PointerEvent) {
    if (this.paused || this.idle) return;
    if (this.locked) {
      this.look(e.movementX, e.movementY, 0.0022);
      return;
    }
    if (e.pointerType !== "touch") this.updateNdc(e);
    const p = this.pointers.get(e.pointerId);
    if (!p) return;
    const dx = e.clientX - p.x;
    const dy = e.clientY - p.y;
    p.x = e.clientX;
    p.y = e.clientY;
    if (!p.moved && Math.hypot(e.clientX - p.sx, e.clientY - p.sy) > 6) p.moved = true;
    if (p.moved) {
      this.look(dx, dy, p.type === "touch" ? 0.0042 : 0.0034);
      this.canvas.style.cursor = "grabbing";
    }
  }

  private onPointerUp(e: PointerEvent) {
    const p = this.pointers.get(e.pointerId);
    this.pointers.delete(e.pointerId);
    this.canvas.style.cursor = this.lastOver ? "pointer" : "grab";
    if (!p || this.paused || this.idle) return;
    if (!p.moved && performance.now() - p.st < 700) {
      const rect = this.canvas.getBoundingClientRect();
      this.tapNdc(((e.clientX - rect.left) / rect.width) * 2 - 1, -(((e.clientY - rect.top) / rect.height) * 2 - 1));
    }
  }

  private updateNdc(e: PointerEvent) {
    const rect = this.canvas.getBoundingClientRect();
    if (!this.pointerNdc) this.pointerNdc = new THREE.Vector2();
    this.pointerNdc.set(((e.clientX - rect.left) / rect.width) * 2 - 1, -(((e.clientY - rect.top) / rect.height) * 2 - 1));
  }

  private look(dx: number, dy: number, sens: number) {
    const p = this.player;
    p.yaw -= clamp(dx, -400, 400) * sens;
    p.pitch = clamp(p.pitch - clamp(dy, -400, 400) * sens, -1.3, 1.3);
    this.focusAnim = null;
  }

  /* ------------------------------------------------------------- hit testing */

  private pick(nx: number, ny: number) {
    this.camera.updateMatrixWorld();
    this.raycaster.setFromCamera(new THREE.Vector2(nx, ny), this.camera);
    const hits = this.raycaster.intersectObjects(this.world.screens, false);
    const h = hits[0];
    if (!h || !h.uv) return null;
    return { screen: h.object.userData.screen as number, u: h.uv.x, v: 1 - h.uv.y };
  }

  private tapNdc(nx: number, ny: number) {
    const hit = this.pick(nx, ny);
    if (hit) this.screens.click(hit.screen, hit.u, hit.v);
  }

  /* ------------------------------------------------------------------- render */

  private resize() {
    if (!this.renderer) return;
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    const base = Math.min(Math.max(window.devicePixelRatio || 1, 1.5), 2);
    const pr = base * [0.6, 0.8, 1][this.quality];
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h, false);
    if (this.composer) {
      this.composer.setPixelRatio(pr);
      this.composer.setSize(w, h);
    }
    const a = w / h;
    this.camera.aspect = a;
    let fov = 72;
    if (a < 1.25) {
      const t = (Math.tan(THREE.MathUtils.degToRad(36)) * 1.25) / a;
      fov = Math.min(100, THREE.MathUtils.radToDeg(2 * Math.atan(t)));
    }
    this.camera.fov = fov;
    this.camera.updateProjectionMatrix();
  }

  private frame = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.frame);
    if (this.paused) return;
    const minGap = this.fps === 30 ? 1000 / 30 - 3 : 0;
    if (now - this.lastRender < minGap) return;
    this.lastRender = now;
    const dt = Math.min(0.05, Math.max(0.001, (now - this.lastFrame) / 1000));
    this.lastFrame = now;
    this.time += dt;
    this.step(dt);

    if (this.quality > 0 && this.composer) this.composer.render();
    else this.renderer.render(this.world.scene, this.camera);
  };

  private step(dt: number) {
    const p = this.player;
    const k = this.keys;

    if (this.idle) {
      // cinematic sway behind the splash screen
      p.x = Math.sin(this.time * 0.1) * 0.6;
      p.z = -3;
      p.yaw = Math.sin(this.time * 0.13) * 0.62;
      p.pitch = 0.05 + Math.sin(this.time * 0.21) * 0.04;
    } else if (this.focusAnim) {
      const f = this.focusAnim;
      f.t += dt / 1.05;
      const e = ease(Math.min(1, f.t));
      p.x = f.fx + (f.tx - f.fx) * e;
      p.z = f.fz + (f.tz - f.fz) * e;
      p.yaw = f.fyaw + (f.tyaw - f.fyaw) * e;
      p.pitch = f.fpitch + (f.tpitch - f.fpitch) * e;
      p.update(dt, 0, 0, this.world.colliders, false, false, this.ev);
      p.x = f.fx + (f.tx - f.fx) * e;
      p.z = f.fz + (f.tz - f.fz) * e;
      if (f.t >= 1) this.focusAnim = null;
    } else {
      let right = this.stick.x;
      let fwd = this.stick.y;
      if (k.has("KeyD")) right += 1;
      if (k.has("KeyA")) right -= 1;
      if (k.has("KeyW")) fwd += 1;
      if (k.has("KeyS")) fwd -= 1;
      const turn = 1.9 * dt;
      if (k.has("ArrowLeft")) p.yaw += turn;
      if (k.has("ArrowRight")) p.yaw -= turn;
      if (k.has("ArrowUp")) p.pitch = clamp(p.pitch + turn * 0.8, -1.3, 1.3);
      if (k.has("ArrowDown")) p.pitch = clamp(p.pitch - turn * 0.8, -1.3, 1.3);
      const crouching = this.crouchToggle || k.has("KeyC") || k.has("ControlLeft");
      const sprint = k.has("ShiftLeft") || k.has("ShiftRight");
      p.update(dt, right, fwd, this.world.colliders, crouching, sprint, this.ev);
    }

    // camera
    this.camera.position.set(p.x, p.eye, p.z);
    this.camera.rotation.set(p.pitch, p.yaw, 0);
    this.camera.updateMatrixWorld();

    // which monitors are in view (intro only plays when it is visible)
    this.projMat.multiplyMatrices(this.camera.projectionMatrix, this.camera.matrixWorldInverse);
    this.frustum.setFromProjectionMatrix(this.projMat);
    for (let i = 0; i < 4; i++) this.visible[i] = this.frustum.intersectsObject(this.world.screens[i]);

    // hover / crosshair
    let over = false;
    const ndc = this.locked ? { x: 0, y: 0 } : this.pointerNdc && !this.idle ? this.pointerNdc : null;
    if (ndc && !this.paused) {
      const hit = this.pick(ndc.x, ndc.y);
      if (hit) over = this.screens.setHover(hit.screen, hit.u, hit.v);
      else this.screens.clearHover();
    } else {
      this.screens.clearHover();
    }
    if (over !== this.lastOver) {
      this.lastOver = over;
      this.cb.onHover(over);
      if (this.pointers.size === 0) this.canvas.style.cursor = over ? "pointer" : "grab";
    }

    // "map is being prepared" progress
    if (!this.screens.state.gameReady) {
      this.loadP += dt / 3.6;
      if (this.screens.setLoad(this.loadP)) {
        this.screens.notify("Карта готова. Выберите режим игры");
        this.audio.ok();
      }
    }

    this.screens.update(dt, this.visible);
    if (this.screens.pendingPing) {
      this.screens.pendingPing = false;
      const dist = Math.hypot(p.x, p.z - 7.9);
      this.audio.ping(clamp(1 - dist / 14, 0, 1));
    }
    this.world.update(this.time, dt);
  }

  /* ------------------------------------------------------------------ dispose */

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.resizeObs?.disconnect();
    this.cleanups.forEach((fn) => fn());
    this.cleanups = [];
    this.exitLock();
    try {
      this.world?.dispose();
      this.screens?.textures.forEach((t) => t.dispose());
      this.composer?.dispose();
      this.renderer?.dispose();
      if (this.canvas?.parentElement) this.canvas.parentElement.removeChild(this.canvas);
    } catch {
      /* ignore */
    }
  }
}
