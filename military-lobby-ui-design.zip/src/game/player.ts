export interface Box {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
}

export function boxFromCenter(cx: number, cy: number, cz: number, w: number, h: number, d: number): Box {
  return {
    minX: cx - w / 2,
    maxX: cx + w / 2,
    minY: cy - h / 2,
    maxY: cy + h / 2,
    minZ: cz - d / 2,
    maxZ: cz + d / 2,
  };
}

export interface PlayerEvents {
  step?: () => void;
  jump?: () => void;
  land?: () => void;
}

const STAND_EYE = 1.7;
const CROUCH_EYE = 1.1;
const RADIUS = 0.32;
const BOUND = 7.5;
const GRAVITY = 12.5;
const JUMP_V = 4.5;
const STEP_UP = 0.36;

export class Player {
  x = 0;
  z = -3;
  feet = 0;
  vy = 0;
  vx = 0;
  vz = 0;
  yaw = 0;
  pitch = 0;
  crouch = 0; // 0..1 eased
  onGround = true;
  moving = 0;
  private stepDist = 0;
  private bob = 0;

  get eye() {
    const base = STAND_EYE - (STAND_EYE - CROUCH_EYE) * this.crouch;
    return this.feet + base + Math.sin(this.bob) * 0.025 * this.moving;
  }

  reset(x: number, z: number, yaw = 0) {
    this.x = x;
    this.z = z;
    this.feet = 0;
    this.vy = 0;
    this.vx = 0;
    this.vz = 0;
    this.yaw = yaw;
    this.pitch = 0;
  }

  jump(ev?: PlayerEvents) {
    if (!this.onGround) return;
    this.vy = JUMP_V;
    this.onGround = false;
    ev?.jump?.();
  }

  private groundAt(boxes: Box[], x: number, z: number) {
    let g = 0;
    for (const b of boxes) {
      if (x > b.minX - RADIUS * 0.6 && x < b.maxX + RADIUS * 0.6 && z > b.minZ - RADIUS * 0.6 && z < b.maxZ + RADIUS * 0.6) {
        if (b.maxY <= this.feet + STEP_UP && b.maxY > g) g = b.maxY;
      }
    }
    return g;
  }

  update(
    dt: number,
    right: number,
    forward: number,
    boxes: Box[],
    crouching: boolean,
    sprint: boolean,
    ev?: PlayerEvents,
  ) {
    // crouch easing
    const ct = crouching ? 1 : 0;
    this.crouch += (ct - this.crouch) * Math.min(1, dt * 11);

    // desired velocity
    let ix = right;
    let iz = forward;
    const len = Math.hypot(ix, iz);
    if (len > 1) {
      ix /= len;
      iz /= len;
    }
    const speed = crouching ? 1.7 : sprint ? 4.8 : 3.1;
    const s = Math.sin(this.yaw);
    const c = Math.cos(this.yaw);
    const tx = (-s * iz + c * ix) * speed;
    const tz = (-c * iz - s * ix) * speed;
    const k = Math.min(1, dt * (this.onGround ? 13 : 3));
    this.vx += (tx - this.vx) * k;
    this.vz += (tz - this.vz) * k;

    this.x += this.vx * dt;
    this.z += this.vz * dt;

    // horizontal collisions
    for (let it = 0; it < 3; it++) {
      for (const b of boxes) {
        if (this.feet + 0.05 >= b.maxY || this.feet + 1.7 <= b.minY) continue;
        const cx = Math.max(b.minX, Math.min(this.x, b.maxX));
        const cz = Math.max(b.minZ, Math.min(this.z, b.maxZ));
        const dx = this.x - cx;
        const dz = this.z - cz;
        const d2 = dx * dx + dz * dz;
        if (d2 >= RADIUS * RADIUS) continue;
        if (d2 > 1e-8) {
          const d = Math.sqrt(d2);
          const push = RADIUS - d;
          this.x += (dx / d) * push;
          this.z += (dz / d) * push;
        } else {
          const l = this.x - b.minX;
          const r = b.maxX - this.x;
          const f = this.z - b.minZ;
          const bk = b.maxZ - this.z;
          const m = Math.min(l, r, f, bk);
          if (m === l) this.x = b.minX - RADIUS;
          else if (m === r) this.x = b.maxX + RADIUS;
          else if (m === f) this.z = b.minZ - RADIUS;
          else this.z = b.maxZ + RADIUS;
        }
      }
    }
    this.x = Math.max(-BOUND, Math.min(BOUND, this.x));
    this.z = Math.max(-BOUND, Math.min(BOUND, this.z));

    // vertical
    this.vy -= GRAVITY * dt;
    this.feet += this.vy * dt;
    const ground = this.groundAt(boxes, this.x, this.z);
    if (this.feet <= ground) {
      const impact = this.vy;
      this.feet = ground;
      this.vy = 0;
      if (!this.onGround && impact < -2.5) ev?.land?.();
      this.onGround = true;
    } else if (this.feet > ground + 0.02) {
      this.onGround = false;
    }

    // bob + footsteps
    const spd = Math.hypot(this.vx, this.vz);
    const target = this.onGround ? Math.min(1, spd / 3) : 0;
    this.moving += (target - this.moving) * Math.min(1, dt * 8);
    if (this.onGround && spd > 0.4) {
      this.bob += dt * spd * 3.1;
      this.stepDist += spd * dt;
      const stride = crouching ? 1.1 : sprint ? 1.9 : 1.5;
      if (this.stepDist > stride) {
        this.stepDist = 0;
        ev?.step?.();
      }
    }
  }
}
